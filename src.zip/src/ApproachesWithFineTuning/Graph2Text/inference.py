import yaml
import json
import time
import sys
import os
import torch
import importlib
from tqdm import tqdm
from openai import OpenAI
from transformers import AutoTokenizer

sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))


with open(f'./config.yaml', 'r') as f:
    configs = yaml.safe_load(f)
response_type = 'with_step' if configs['response_template_name']=='response_with_step_template' else 'without_step'


def count_tokens_qwen(prompt, model_name):
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    tokens = tokenizer.encode(prompt, add_special_tokens=True)
    return len(tokens)


def import_template(template_type, template_name):    
    if template_type == 'instruction':
        module = importlib.import_module('DatasetConstruction.Templates.InstructionTemplate')
    elif template_type == 'response':
        module = importlib.import_module('DatasetConstruction.Templates.ResponseTemplate')
    elif template_type == 'codeprompt':
        module = importlib.import_module('DatasetConstruction.Templates.CodePromptTemplate')
    return getattr(module, template_name)


def ask_llm(user_instruction, system_prompt):
    client = OpenAI(base_url=configs['api_base'], api_key=configs['api_key'])
    token_count = count_tokens_qwen(user_instruction+system_prompt, configs['llm_path'])   
    
    return None, token_count

    # if token_count >= 129024:
    #     return None, token_count
    
    # MAX_RETRIES = 5
    # WAIT_TIME = 2
    # retries = 0
    # while retries < MAX_RETRIES:
    #     try:
    #         completion = client.chat.completions.create(
    #             messages=[
    #                 {
    #                     "role": "user",
    #                     "content": user_instruction
    #                 },
    #                 {
    #                     "role": "system",
    #                     "content": system_prompt
    #                 }
    #             ],
    #             model=configs['llm_name'],
    #             temperature=0,
    #             timeout=60
    #         )
    #         content = completion.choices[0].message.content
    #         return content, token_count
    #     except:
    #         retries += 1
    #         if retries >= MAX_RETRIES:
    #             return None, token_count
    #         time.sleep(WAIT_TIME)
    #         WAIT_TIME *= 2


if __name__ == '__main__':
    
    BENCH_PATH = configs['trace_bench_dataset']
    OUTPUT_FILE = configs['output_path'] + f"/LLMresponses_{configs['llm_name']}_Graph2Text_{configs['desc_method']}_{response_type}.json"

    test_tasks = torch.load(BENCH_PATH+'/test/preprocessed/0.pt')
    # test_tasks = dict(list(test_tasks.items())[:100])
    
    response_results = dict()
    for problem_id, task_info in tqdm(test_tasks.items(), desc='LLM Response'):
        # step1: 将 instruction 和 trace 拼接好，需要判断instruction类型
        # user instruction
        ## instruction
        instruction_name = list()
        instruction_name.append('instruction')
        instruction_name.append(configs['desc_method'])
        instruction_name.append(response_type)
        instruction_name = '_'.join(instruction_name)
        ## input
        input_name = list()
        input_name.append('input_trace')
        input_name.append(configs['desc_method'])
        input_name = '_'.join(input_name)
        ## user instruction
        user_instruction = task_info[instruction_name] + '\n' + task_info[input_name]
        # system prompt
        system_prompt_name = list()
        system_prompt_name.append('system_prompt')
        system_prompt_name.append(response_type)
        system_prompt_name = '_'.join(system_prompt_name)
        system_prompt = import_template(template_type='instruction', template_name=system_prompt_name)
        # response
        response_name = list()
        response_name.append('response')
        response_name.append(response_type)
        response_name = '_'.join(response_name)

        # step2: 调用 ask_llm
        response, token_count = ask_llm(user_instruction, system_prompt)
        
        # step3: 保存 LLM 生成的 response
        response_results[problem_id] = dict()
        response_results[problem_id]['task_id'] = task_info['task_id']
        response_results[problem_id]['type_id'] = task_info['type_id']
        response_results[problem_id]['gt_response'] = task_info[response_name]
        response_results[problem_id]['gt_answer'] = task_info['answer']
        response_results[problem_id]['llm_response'] = response
        response_results[problem_id]['token_count'] = token_count

    with open(OUTPUT_FILE, 'w') as file:
        json.dump(response_results, file, indent=4)


    print('Done!')