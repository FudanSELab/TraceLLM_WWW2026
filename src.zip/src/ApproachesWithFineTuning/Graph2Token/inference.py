import os
import torch
import wandb
import gc
import yaml
import json
import time
import datetime
from tqdm import tqdm
from torch.utils.data import DataLoader
from src.utils.seed import seed_everything
from src.utils.dataset import TraceInstructionDataset
from src.utils.collate import collate_fn
from src.utils.ckpt import _reload_latest_model
from src.utils.graph_batch import get_graph_batch
from src.model import load_model


with open(f'./config.yaml', 'r') as f:
    configs = yaml.safe_load(f)
response_type = 'with_step' if configs['response_template_name']=='response_with_step_template' else 'without_step'


def main():
    seed = configs['seed']
    wandb.init(project=f"{configs['project']}",
               name=f"{configs['model_name']}_seed{seed}",
               config=configs)

    seed_everything(seed=seed)

    # Step 2: Build Dataset
    test_dataset = TraceInstructionDataset(root=configs['trace_bench_dataset'], dataset_type='test')
    test_loader = DataLoader(dataset=test_dataset, batch_size=configs['eval_batch_size'], drop_last=False, pin_memory=True, shuffle=False, collate_fn=collate_fn)
    processed_dir = os.path.join(configs['trace_bench_dataset'], 'test', 'processed')
    data_info_file = os.path.join(processed_dir, 'data_info.json')
    with open(data_info_file, 'r') as file:
        data_info = json.load(file)

    # Step 3: Build Model
    model = load_model[configs['model_name']](configs=configs)
    model = _reload_latest_model(model=model, configs=configs)

    # Step 4. Evaluating
    model.eval()
    eval_output = dict()
    for batch in tqdm(test_loader, desc='Evaluating'):
        with torch.no_grad():
            trace_id_batch = batch['trace_id']
            graph_batch = get_graph_batch(trace_ids=trace_id_batch, configs=configs, data_info=data_info, processed_dir=processed_dir)
            output = model.inference(batch, graph_batch)
            eval_output.update(output)

    # Step 5. Post-processing
    OUTPUT_FILE = configs['output_path'] + f"/LLMresponses_{configs['llm_name']}_Graph2Token_{configs['desc_method']}_{response_type}_{'freeze' if configs['llm_frozen'] else 'lora'}.json"
    with open(OUTPUT_FILE, 'w') as file:
        json.dump(eval_output, file, indent=4)

    print('Done!')


if __name__ == "__main__":
    start_time = time.time() 
    main()
    total_time = time.time() - start_time
    total_time_str = str(datetime.timedelta(seconds=int(total_time)))
    print("-"*20)
    print("Training time {}".format(total_time_str))
    print("-"*20)

    torch.cuda.empty_cache()
    torch.cuda.reset_max_memory_allocated()
    gc.collect()