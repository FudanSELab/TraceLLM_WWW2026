import contextlib
import time
import os
import json
import torch
import torch.nn as nn
import numpy as np
from tqdm import tqdm
from torch.cuda.amp import autocast as autocast
from transformers import AutoModelForCausalLM, AutoTokenizer
from peft import (
    LoraConfig,
    get_peft_model,
    get_peft_model_state_dict,
    prepare_model_for_kbit_training,
    set_peft_model_state_dict,
)


from src.model.gnn import load_gnn_model


ignore_index = -100


class GraphLLM(torch.nn.Module):

    def __init__(
        self,
        configs
    ):
        super().__init__()
        self.max_txt_len = configs['max_txt_len']
        self.max_new_tokens = configs['max_new_tokens']

        print(f"Loading {configs['llm_name']}")
        available_gpus = list(range(torch.cuda.device_count()))
        kwargs = {
            "max_memory": {i: '20GiB' for i in available_gpus},
            "device_map": "auto",
            "revision": "main",
        }

        self.tokenizer = AutoTokenizer.from_pretrained(pretrained_model_name_or_path=configs['llm_path'], use_fast=False, revision=kwargs["revision"])
        self.tokenizer.pad_token_id = 0
        llm_config_path = os.path.join(configs['llm_path'], 'config.json')
        with open(llm_config_path, 'r') as file:
            llm_config = json.load(file)
        self.llm_hidden_size = llm_config['hidden_size']
        self.tokenizer.bos_token_id = llm_config['bos_token_id']
        self.tokenizer.padding_side = 'left'

        model = AutoModelForCausalLM.from_pretrained(
            configs['llm_path'],
            torch_dtype=torch.float16,
            low_cpu_mem_usage=True,
            **kwargs
        )

        if configs['llm_frozen'] == True:
            print(f"Freezing {configs['llm_name']}!")
            for name, param in model.named_parameters():
                param.requires_grad = False
        else:
            print(f"Training {configs['llm_name']} with LORA!")
            model = prepare_model_for_kbit_training(model)
            lora_r: int = 8
            lora_alpha: int = 16
            lora_dropout: float = 0.05
            lora_target_modules = [
                "q_proj",
                "v_proj",
            ]
            config = LoraConfig(
                r=lora_r,
                lora_alpha=lora_alpha,
                target_modules=lora_target_modules,
                lora_dropout=lora_dropout,
                bias="none",
                task_type="CAUSAL_LM",
            )
            model = get_peft_model(model, config)

        self.model = model
        print(f"Finish loading {configs['llm_name']}!")

        # node_attrs_info_path = os.path.join(configs['trace_bench_dataset'], 'train', 'processed', 'node_attrs_info.json')
        # with open(node_attrs_info_path, 'r') as file:
        #     node_attrs_info = json.load(file)
        # self.max_token_length = self._get_max_token_length(node_attrs_info)
        self.max_token_length = self.max_txt_len

        self.graph_encoder = load_gnn_model[configs['gnn_model_name']](
            in_channels=self.llm_hidden_size,
            hidden_channels=configs['gnn_hidden_dim'],
            out_channels=configs['gnn_out_dim'],
            num_layers=configs['gnn_num_layers'],
            dropout=configs['gnn_dropout'],
            num_heads=configs['gnn_num_heads'],
        ).to(self.model.device)

        self.projector = nn.Sequential(
            nn.Linear(configs['gnn_out_dim'], 2048),
            nn.Sigmoid(),
            nn.Linear(2048, self.llm_hidden_size),   
        ).to(self.model.device)

        self.pooling_type = configs['gnn_pooling_type']

        self.word_embedding = self.model.model.get_input_embeddings()

        # self.node_initial_embeddings_path = node_embeddings_path

    @property
    def device(self):
        return list(self.parameters())[0].device

    def maybe_autocast(self, dtype=torch.bfloat16):
        # if on cpu, don't use autocast
        # if on gpu, use autocast with dtype if provided, otherwise use torch.float16
        enable_autocast = self.device != torch.device("cpu")

        if enable_autocast:
            return torch.amp.autocast(dtype=dtype, device_type='cuda')
        else:
            return contextlib.nullcontext()

    def encode_graphs(self, graph_samples):
        n_embeds = self.graph_encoder(graph_samples['x'], graph_samples['edge_index'], graph_samples['batch'], self.pooling_type)
        inputs_embeds = self.projector(n_embeds)
        return inputs_embeds
    
    def _get_projector(self, batch_embeds):
        batch_projector_embeds = list()
        for embeds_pair in batch_embeds:
            projector_embeds = list()
            for embed in embeds_pair:
                projector_embed = self.projector(embed)
                projector_embeds.append(projector_embed)
            batch_projector_embeds.append(projector_embeds)
        return batch_projector_embeds

    def _get_edge_index(self, batch_input_traces):
        batch_level_edge_index = list()
        for input_traces in batch_input_traces:
            input_traces_level_edge_index = list()
            for input_trace in input_traces:
                edge_index = input_trace['edge_index'].to(self.model.device)
                input_traces_level_edge_index.append(edge_index)
            batch_level_edge_index.append(input_traces_level_edge_index)
        return batch_level_edge_index

    def _encode_node_attrs(self, batch_trace_ids):
        batch_level_feats = list()
        for trace_ids in batch_trace_ids:
            trace_ids_level_feats = list()
            for trace_id in trace_ids:
                node_feats_file = os.path.join(self.node_initial_embeddings_path, f'{trace_id}.json')
                with open(node_feats_file, 'r') as file:
                    node_feats = json.load(file)
                node_feats = torch.tensor(np.asarray(node_feats), dtype=torch.float).to(self.model.device)                   
                trace_ids_level_feats.append(node_feats)
            batch_level_feats.append(trace_ids_level_feats)
        return batch_level_feats

    def _get_max_token_length(self, node_attrs_info):
        max_token_length = -1
        for node_attr in tqdm(node_attrs_info, desc='Tokenizer'):
            token_length = len(self.tokenizer(node_attr)['input_ids'])
            if token_length > max_token_length:
                max_token_length = token_length
        print('max_token_length:', str(max_token_length))
        return max_token_length

    def forward(self, samples, graph_samples):
        # encode instructions and responses
        instructions = self.tokenizer(samples['instruction'], add_special_tokens=False)
        responses = self.tokenizer(samples['response'], add_special_tokens=False)
        # encode special tokens
        pad_embeds = self.word_embedding(torch.tensor(self.tokenizer.pad_token_id, device=self.model.device)).unsqueeze(0)
        bos_embeds = self.word_embedding(torch.tensor(self.tokenizer.bos_token_id, device=self.model.device)).unsqueeze(0)
        # encode graphs
        graph_embeds = self.encode_graphs(graph_samples=graph_samples.to(self.model.device))
        graph_embeds = [emb.unsqueeze(0) for emb in graph_embeds]    # stack
        batch_size = len(samples['problem_id'])
        batch_inputs_embeds = []
        batch_attention_mask = []
        batch_response_input_ids = []
        for i in range(batch_size):
            # Get graph list
            graph_list = list()
            input_trace_count = len(samples['trace_id'][i])
            for _ in range(input_trace_count):
                graph_list.append(graph_embeds.pop(0))
            # Add bos & eos token
            response_input_ids = responses.input_ids[i] + [self.tokenizer.eos_token_id]
            input_ids = instructions.input_ids[i] + response_input_ids
            inputs_embeds = self.word_embedding(torch.tensor(input_ids).to(self.model.device))
            inputs_embeds = torch.cat([bos_embeds]+graph_list+[inputs_embeds], dim=0)

            batch_inputs_embeds.append(inputs_embeds)
            batch_attention_mask.append([1] * inputs_embeds.shape[0])
            response_input_ids = [ignore_index] * (inputs_embeds.shape[0]-len(response_input_ids))+response_input_ids
            batch_response_input_ids.append(response_input_ids)
        
        # pad inputs_embeds
        max_length = max([x.shape[0] for x in batch_inputs_embeds])
        for i in range(batch_size):
            pad_length = max_length-batch_inputs_embeds[i].shape[0]
            batch_inputs_embeds[i] = torch.cat([pad_embeds.repeat(pad_length, 1), batch_inputs_embeds[i]])
            batch_attention_mask[i] = [0]*pad_length+batch_attention_mask[i]
            batch_response_input_ids[i] = [ignore_index] * pad_length+batch_response_input_ids[i]

        inputs_embeds = torch.stack(batch_inputs_embeds, dim=0).to(self.model.device)
        attention_mask = torch.tensor(batch_attention_mask).to(self.model.device)
        response_input_ids = torch.tensor(batch_response_input_ids).to(self.model.device)
        
        with self.maybe_autocast():
            outputs = self.model(
                inputs_embeds=inputs_embeds,
                attention_mask=attention_mask,
                return_dict=True,
                labels=response_input_ids,
            )

        return outputs.loss


    def inference(self, samples, graph_samples):

        # encode instructions
        instructions = self.tokenizer(samples['instruction'], add_special_tokens=False)

        # encode special tokens
        pad_embeds = self.word_embedding(torch.tensor(self.tokenizer.pad_token_id, device=self.model.device)).unsqueeze(0)
        bos_embeds = self.word_embedding(torch.tensor(self.tokenizer.bos_token_id, device=self.model.device)).unsqueeze(0)

        # encode graphs
        graph_embeds = self.encode_graphs(graph_samples=graph_samples.to(self.model.device))
        graph_embeds = [emb.unsqueeze(0) for emb in graph_embeds]    # stack

        batch_size = len(samples['problem_id'])
        batch_inputs_embeds = []
        batch_attention_mask = []
        for i in range(batch_size):
            # Get graph list
            graph_list = list()
            input_trace_count = len(samples['trace_id'][i])
            for _ in range(input_trace_count):
                graph_list.append(graph_embeds.pop(0))
            # Add bos & eos token
            input_ids = instructions.input_ids[i]
            inputs_embeds = self.word_embedding(torch.tensor(input_ids).to(self.model.device))
            inputs_embeds = torch.cat([bos_embeds]+graph_list+[inputs_embeds], dim=0)

            batch_inputs_embeds.append(inputs_embeds)
            batch_attention_mask.append([1] * inputs_embeds.shape[0])

        # pad inputs_embeds
        max_length = max([x.shape[0] for x in batch_inputs_embeds])
        for i in range(batch_size):
            pad_length = max_length-batch_inputs_embeds[i].shape[0]
            batch_inputs_embeds[i] = torch.cat([pad_embeds.repeat(pad_length, 1), batch_inputs_embeds[i]])
            batch_attention_mask[i] = [0]*pad_length+batch_attention_mask[i]

        inputs_embeds = torch.stack(batch_inputs_embeds, dim=0).to(self.model.device)
        attention_mask = torch.tensor(batch_attention_mask).to(self.model.device)

        with self.maybe_autocast():
            outputs = self.model.generate(
                inputs_embeds=inputs_embeds,
                max_new_tokens=self.max_new_tokens,  
                attention_mask=attention_mask,
                pad_token_id=self.tokenizer.eos_token_id,
                # do_sample=True,
                use_cache=True
            )
        pred = self.tokenizer.batch_decode(outputs, skip_special_tokens=True)

        response_results = dict()
        for i in range(batch_size):
            problem_id = samples['problem_id'][i]
            response_results[problem_id] = dict()
            response_results[problem_id]['task_id'] = samples['task_id'][i]
            response_results[problem_id]['type_id'] = samples['type_id'][i]
            response_results[problem_id]['gt_response'] = samples['response'][i]
            response_results[problem_id]['gt_answer'] = samples['answer'][i]
            response_results[problem_id]['llm_response'] = pred[i]

        return response_results        


    def print_trainable_params(self):
        trainable_params = 0
        all_param = 0

        for _, param in self.named_parameters():
            num_params = param.numel()

            all_param += num_params
            if param.requires_grad:
                trainable_params += num_params

        return trainable_params, all_param
