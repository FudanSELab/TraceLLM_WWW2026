from src.model.graph_llm import GraphLLM
from src.model.llm import LLM
from src.model.gnn import GCN
from src.model.gnn import GAT
from src.model.llama_adapter import LlamaAdapter

load_model = {
    'graph_llm': GraphLLM,
    'llm': LLM,
    'inference_llm': LLM,
    'gcn': GCN,
    'gat': GAT,
    'llama_adapter': LlamaAdapter,
}