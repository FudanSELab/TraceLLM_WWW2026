import json
import os
import yaml
import pandas as pd
import torch
from torch.utils.data import Dataset


with open(f'./config.yaml', 'r') as f:
    configs = yaml.safe_load(f)


class TraceInstructionDataset(Dataset):
    def __init__(self, root, dataset_type):
        super().__init__()

        self.root = root
        self.dataset_type = dataset_type
        self.desc_method = configs['desc_method']
        self.response_template_name = configs['response_template_name']

        self.tasks = torch.load(self.tasks_file_name)
        self.tasks = sorted(self.tasks.items(), key=lambda x: x[0])
        with open(self.data_info_file_name, 'r') as file:
            self.data_info = json.load(file)


    def __len__(self):
        """Return the length of the dataset."""
        return len(self.tasks)


    def __getitem__(self, index):
        if isinstance(index, int):
            problem_id, task_content = self.tasks[index]

            if isinstance(task_content['trace_id'], list):
                input_trace_data = [self._get_trace_data(trace_id) for trace_id in task_content['trace_id']]
            else:
                input_trace_data = [self._get_trace_data(task_content['trace_id'])]
            
            # instruction
            instruction_name = list()
            instruction_name.append('instruction')
            instruction_name.append(self.desc_method)
            if self.response_template_name == 'response_with_step_template':
                instruction_name.append('with_step')
            elif self.response_template_name == 'response_without_step_template':
                instruction_name.append('without_step')
            instruction_name = '_'.join(instruction_name)

            # response
            response_name = list()
            response_name.append('response')
            if self.response_template_name == 'response_with_step_template':
                response_name.append('with_step')
            elif self.response_template_name == 'response_without_step_template':
                response_name.append('without_step')
            response_name = '_'.join(response_name)

            return {
                'problem_id': problem_id,
                'task_id': task_content['task_id'],
                'type_id': task_content['type_id'],
                'trace_id': task_content['trace_id'] if isinstance(task_content['trace_id'], list) else [task_content['trace_id']],
                # 'input_trace': input_trace_data,
                'instruction': task_content[instruction_name],
                'response': task_content[response_name],
                'answer': task_content['answer']
            }


    @property
    def tasks_file_name(self) -> str:
        return os.path.join(self.root, self.dataset_type, 'preprocessed', '0.pt')


    @property
    def data_info_file_name(self) -> str:
        return os.path.join(self.processed_dir, 'data_info.json')


    @property
    def processed_dir(self) -> str:
        return os.path.join(self.root, self.dataset_type, 'processed')


    def _get_trace_data(self, trace_id):
        trace_idx = self.data_info[trace_id]
        file_name = 'data_{}.pt'.format(trace_idx)
        trace_data = torch.load(os.path.join(self.processed_dir, file_name), weights_only=False)
        return trace_data


if __name__ == '__main__':
    dataset = TraceInstructionDataset(root='./dataset/TraceBench', dataset_type='test')

    print(len(dataset.tasks))

    for task in dataset:
        print(task)
        print('-'*10)