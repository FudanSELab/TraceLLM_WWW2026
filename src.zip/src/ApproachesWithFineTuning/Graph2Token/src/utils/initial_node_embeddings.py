import json
import os
import yaml
import torch
import time
import numpy as np
from tqdm import tqdm
from transformers import AutoModelForCausalLM, AutoTokenizer
from multiprocessing import Pool

processes_num = 8


with open(f'./config.yaml', 'r') as f:
    configs = yaml.safe_load(f)


def work(job):
    trace_file_name = 'data_{}.pt'.format(job['trace_file_idx'])
    input_trace = torch.load(os.path.join(configs['trace_bench_dataset'], 'train', 'processed', trace_file_name), weights_only=False)

    # print('[input_trace_file]', trace_file_name)

    node_feats = list()
    node_attrs = input_trace['node_text']
    for node_attr in node_attrs:
        node_attr_tokens = job['tokenizer'](node_attr, padding='max_length', max_length=configs['max_txt_len'], return_tensors='pt')
        node_attr_input_ids = node_attr_tokens['input_ids']
        node_attr_attention_mask = node_attr_tokens['attention_mask']
        if configs['with_transformers']:
            with torch.no_grad():
                outputs = job['model'](**node_attr_tokens)
            node_attr_embeds = outputs.last_hidden_state
        else:
            node_attr_embeds = job['word_embedding'](node_attr_input_ids)
        mask = node_attr_attention_mask.unsqueeze(-1).expand(node_attr_embeds.size()).to(node_attr_embeds.device)
        masked_node_attr_embeds = node_attr_embeds * mask
        summed = masked_node_attr_embeds.sum(dim=1)
        counted = mask.sum(dim=1)
        # mean pooling
        mean_pooled = summed / counted
        node_feats.append(mean_pooled.squeeze(0).detach().cpu().numpy().tolist())

    # res_file = os.path.join(job['output_path'], f"{job['trace_id']}.json")
    # with open(res_file, 'w') as file:
    #     json.dump(node_feats, file)
    res_file = os.path.join(job['output_path'], f"{job['trace_id']}.pt")
    torch.save(node_feats, res_file)


def generate_initial_node_embeddings(configs, embeddings_path):
    os.makedirs(embeddings_path, exist_ok=True)

    data_info_path = os.path.join(configs['trace_bench_dataset'], 'train', 'processed', 'data_info.json')
    with open(data_info_path, 'r') as file:
        data_info = json.load(file)

    available_gpus = list(range(torch.cuda.device_count()))
    kwargs = {
        "max_memory": {i: '20GiB' for i in available_gpus},
        "device_map": "auto",
        "revision": "main",
    }
    tokenizer = AutoTokenizer.from_pretrained(pretrained_model_name_or_path=configs['llm_path'], use_fast=False, revision=kwargs["revision"])
    tokenizer.pad_token_id = 0
    llm_config_path = os.path.join(configs['llm_path'], 'config.json')
    with open(llm_config_path, 'r') as file:
        llm_config = json.load(file)
    llm_hidden_size = llm_config['hidden_size']
    tokenizer.bos_token_id = llm_config['bos_token_id']
    tokenizer.padding_side = 'left'

    model = AutoModelForCausalLM.from_pretrained(
        configs['llm_path'],
        torch_dtype=torch.float16,
        low_cpu_mem_usage=True,
        **kwargs
    )
    word_embedding = model.model.get_input_embeddings()
    

    jobs = list()    
    for trace_id, idx in data_info.items():
        jobs.append({
            'trace_id': trace_id,
            'trace_file_idx': idx,
            'output_path': embeddings_path,
            'tokenizer': tokenizer,
            'model': model,
            'word_embedding': word_embedding
        })
    # with Pool(processes_num) as p:
    #     p.map(work, jobs)
    
    for job in tqdm(jobs, desc='Jobs'):
        work(job)

    print('[END] Generate initial node embeddings!')


if __name__ == '__main__':
    with open(f'./config.yaml', 'r') as f:
        configs = yaml.safe_load(f)
    
    node_initial_embeddings_path = os.path.join(configs['trace_bench_dataset'], 'initial_node_embeddings', f"{configs['llm_name']}_{'wTrans' if configs['with_transformers'] else 'woTrans'}")
    generate_initial_node_embeddings(configs=configs, embeddings_path=node_initial_embeddings_path)

    print('Done!')