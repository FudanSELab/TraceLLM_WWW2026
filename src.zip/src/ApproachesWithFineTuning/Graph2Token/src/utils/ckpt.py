import os
import torch


def print_trainable_params(model):
    trainable_params = 0
    all_param = 0

    for _, param in model.named_parameters():
        num_params = param.numel()

        all_param += num_params
        if param.requires_grad:
            trainable_params += num_params

    return trainable_params, all_param


def _save_checkpoint(model, optimizer, cur_epoch, configs, is_best=False):
    """
    Save the checkpoint at the current epoch.
    """

    os.makedirs(os.path.join(configs['output_path'], configs['model_name']), exist_ok=True)

    param_grad_dic = {
        k: v.requires_grad for (k, v) in model.named_parameters()
    }
    state_dict = model.state_dict()
    for k in list(state_dict.keys()):
        if k in param_grad_dic.keys() and not param_grad_dic[k]:
            # delete parameters that do not require gradient
            del state_dict[k]
    save_obj = {
        "model": state_dict,
        "optimizer": optimizer.state_dict(),
        "config": configs,
        "epoch": cur_epoch,
    }

    path = f"{configs['model_name']}_{configs['llm_name']}_{configs['gnn_model_name']}_{configs['gnn_pooling_type']}_seed{configs['seed']}_{configs['desc_method']}_{configs['response_template_name']}_{'wTrans' if configs['with_transformers'] else 'woTrans'}_{'freeze' if configs['llm_frozen'] else 'lora'}"
    save_to = os.path.join(
        configs['output_path'],
        configs['model_name'],
        path+"_checkpoint_{}.pth".format("best" if is_best else cur_epoch),
    )

    print("Saving checkpoint at epoch {} to {}.".format(cur_epoch, save_to))
    torch.save(save_obj, save_to)

    if cur_epoch > 0:
        os.remove(os.path.join(
            configs['output_path'],
            configs['model_name'],
            path+"_checkpoint_{}.pth".format(cur_epoch-1),
        ))
        print("Remove previous checkpoint at epoch {}.".format(cur_epoch-1))


def _reload_best_model(model, configs):
    """
    Load the best checkpoint for evaluation.
    """

    path = f"{configs['model_name']}_{configs['llm_name']}_{configs['gnn_model_name']}_{configs['gnn_pooling_type']}_seed{configs['seed']}_checkpoint_best.pth"
    checkpoint_path = os.path.join(configs['output_path'], path)

    print("Loading checkpoint from {}.".format(checkpoint_path))

    checkpoint = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
    model.load_state_dict(checkpoint["model"], strict=False)

    return model


def _reload_latest_model(model, configs):
    """
    Load the latest checkpoint for evaluation.
    """

    path = f"{configs['model_name']}_{configs['llm_name']}_{configs['gnn_model_name']}_{configs['gnn_pooling_type']}_seed{configs['seed']}_{configs['desc_method']}_{configs['response_template_name']}_{'wTrans' if configs['with_transformers'] else 'woTrans'}_{'freeze' if configs['llm_frozen'] else 'lora'}"
    checkpoint_file = os.path.join(
        configs['output_path'],
        configs['model_name'],
        path+"_checkpoint_{}.pth".format(configs['num_epochs']-1),
    )

    print("Loading checkpoint from {}.".format(checkpoint_file))

    checkpoint = torch.load(checkpoint_file, map_location="cpu", weights_only=False)
    model.load_state_dict(checkpoint['model'], strict=False)

    return model
