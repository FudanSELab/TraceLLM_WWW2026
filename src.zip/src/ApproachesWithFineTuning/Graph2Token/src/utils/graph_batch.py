import json
import os
import torch
import time
import numpy as np
from itertools import chain
from torch_geometric.data import Batch
from functools import lru_cache
from concurrent.futures import ThreadPoolExecutor

maxsize = 512


# @lru_cache(maxsize=maxsize)
def get_trace_data(trace_id, processed_dir, trace_idx):
    file_name = 'data_{}.pt'.format(trace_idx)
    trace_data = torch.load(os.path.join(processed_dir, file_name), weights_only=False)
    return trace_data


# @lru_cache(maxsize=maxsize)
def get_node_embeddings(trace_id, node_initial_embeddings_path):
    node_feats_file = os.path.join(node_initial_embeddings_path, f'{trace_id}.pt')
    node_feats = torch.load(node_feats_file, weights_only=False)
    node_feats = torch.tensor(np.asarray(node_feats), dtype=torch.float)
    return node_feats


def process_trace_data(trace_id, processed_dir, data_info, node_initial_embeddings_path):
    trace_data = get_trace_data(trace_id, processed_dir, data_info[trace_id])
    node_embeddings = get_node_embeddings(trace_id, node_initial_embeddings_path)
    trace_data['x'] = node_embeddings
    return trace_data


def get_graph_batch(trace_ids, configs, data_info, processed_dir):

    node_initial_embeddings_path = os.path.join(configs['trace_bench_dataset'], 'initial_node_embeddings', f"{configs['llm_name']}_{'wTrans' if configs['with_transformers'] else 'woTrans'}")

    trace_ids = list(chain.from_iterable(trace_ids))

    # with ThreadPoolExecutor(max_workers=configs['num_workers']) as executor:
    #     trace_batch_list = list(executor.map(
    #         lambda trace_id: process_trace_data(trace_id=trace_id, processed_dir=processed_dir, data_info=data_info, node_initial_embeddings_path=node_initial_embeddings_path),
    #         trace_ids
    #     ))

    trace_batch_list = list()
    for trace_id in trace_ids:
        trace_data = get_trace_data(trace_id, processed_dir, data_info[trace_id])
        node_embeddings = get_node_embeddings(trace_id, node_initial_embeddings_path)
        trace_data['x'] = node_embeddings
        trace_batch_list.append(trace_data)
        
    trace_batch = Batch.from_data_list(trace_batch_list)
    
    return trace_batch