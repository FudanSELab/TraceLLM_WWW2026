import torch
import wandb
import copy
import gc
import os
import yaml
import time
import datetime
import json
from tqdm import tqdm
from torch.utils.data import DataLoader
from torch.nn.utils import clip_grad_norm_

from src.utils.seed import seed_everything
from src.utils.lr_schedule import adjust_learning_rate
from src.utils.dataset import TraceInstructionDataset
from src.utils.ckpt import _save_checkpoint
from src.utils.collate import collate_fn
from src.utils.graph_batch import get_graph_batch
from src.utils.initial_node_embeddings import generate_initial_node_embeddings
from src.model import load_model


with open(f'./config.yaml', 'r') as f:
    configs = yaml.safe_load(f)


def main():
    seed = configs['seed']
    wandb.init(project=f"{configs['project']}",
               name=f"{configs['model_name']}_seed{seed}",
               config=configs)

    seed_everything(seed=seed)

    # Step 1: Init Node Embedding
    node_initial_embeddings_path = os.path.join(configs['trace_bench_dataset'], 'initial_node_embeddings', f"{configs['llm_name']}_{'wTrans' if configs['with_transformers'] else 'woTrans'}")
    if not os.path.exists(node_initial_embeddings_path):
        print(f'[START] Generate initial node embeddings in {node_initial_embeddings_path}...')
        generate_initial_node_embeddings(configs=configs, embeddings_path=node_initial_embeddings_path)


    # Step 2: Build Dataset
    train_dataset = TraceInstructionDataset(root=configs['trace_bench_dataset'], dataset_type='train')
    train_loader = DataLoader(dataset=train_dataset, batch_size=configs['batch_size'], drop_last=True, pin_memory=True, shuffle=True, collate_fn=collate_fn, num_workers=configs['num_workers'])
    processed_dir = os.path.join(configs['trace_bench_dataset'], 'train', 'processed')
    data_info_file = os.path.join(processed_dir, 'data_info.json')
    with open(data_info_file, 'r') as file:
        data_info = json.load(file)

    # Step 3: Build Model
    model = load_model[configs['model_name']](configs=configs)


    # Step 4: Set Optimizer
    params = [p for _, p in model.named_parameters() if p.requires_grad]
    optimizer = torch.optim.AdamW(params=params, betas=(0.9, 0.95), lr=float(configs['lr']), weight_decay=configs['wd'])
    trainable_params, all_param = model.print_trainable_params()
    print(f"trainable params: {trainable_params} || all params: {all_param} || trainable%: {100 * trainable_params / all_param}")


    # Step 5: Training
    for epoch in range(configs['num_epochs']):

        model.train()
        epoch_loss, accum_loss = 0., 0.

        # start_time = time.time()

        step = 0
        for batch in tqdm(train_loader, desc=f'Epoch {epoch}'):
            trace_id_batch = batch['trace_id']
            graph_batch = get_graph_batch(trace_ids=trace_id_batch, configs=configs, data_info=data_info, processed_dir=processed_dir)

            optimizer.zero_grad()
            loss = model(batch, graph_batch)
            loss.backward()

            clip_grad_norm_(optimizer.param_groups[0]['params'], 0.1)
 
            if (step + 1) % configs['grad_steps'] == 0:
                adjust_learning_rate(optimizer.param_groups[0], step / len(train_loader) + epoch, configs)

            optimizer.step()
            epoch_loss, accum_loss = epoch_loss + loss.item(), accum_loss + loss.item()

            if (step + 1) % configs['grad_steps'] == 0:
                lr = optimizer.param_groups[0]["lr"]
                wandb.log({'Lr': lr})
                wandb.log({'Accum Loss': accum_loss / configs['grad_steps']})
                accum_loss = 0.
            
            step += 1

        print(f"Epoch: {epoch}|{configs['num_epochs']}: Train Loss (Epoch Mean): {epoch_loss / len(train_loader)}")
        wandb.log({'Train Loss (Epoch Mean)': epoch_loss / len(train_loader)})        
        _save_checkpoint(model=model, optimizer=optimizer, cur_epoch=epoch, configs=configs)


    print('Done!')

    torch.cuda.empty_cache()
    torch.cuda.reset_max_memory_allocated()


if __name__ == "__main__":
    start_time = time.time() 
    main()
    total_time = time.time() - start_time
    total_time_str = str(datetime.timedelta(seconds=int(total_time)))
    print("-"*20)
    print("Training time {}".format(total_time_str))
    print("-"*20)

    torch.cuda.empty_cache()
    torch.cuda.reset_max_memory_allocated()
    gc.collect()