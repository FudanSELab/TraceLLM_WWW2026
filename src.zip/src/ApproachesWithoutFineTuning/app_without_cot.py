import yaml
import json
import time
import datetime
import sys
import os
import torch
import importlib
from tqdm import tqdm
from openai import OpenAI
from transformers import AutoModelForCausalLM, AutoTokenizer

sys.path.append(os.path.dirname(os.path.dirname(__file__)))


with open(f'./config.yaml', 'r') as f:
    configs = yaml.safe_load(f)
response_type = 'with_step' if configs['response_template_name']=='response_with_step_template' else 'without_step'


def count_tokens_qwen(prompt, model_name):
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    tokens = tokenizer.encode(prompt, add_special_tokens=True)
    return len(tokens)


def split_from_mark(s, mark):
    index = s.find(mark)
    if index == -1:
        return s, ''  
    return s[:index], s[index:]


def import_template(template_type, template_name):    
    if template_type == 'instruction':
        module = importlib.import_module('DatasetConstruction.Templates.InstructionTemplate')
    elif template_type == 'response':
        module = importlib.import_module('DatasetConstruction.Templates.ResponseTemplate')
    elif template_type == 'codeprompt':
        module = importlib.import_module('DatasetConstruction.Templates.CodePromptTemplate')
    return getattr(module, template_name)


def ask_llm(tokenizer, model, user_instruction, system_prompt):
    token_count = count_tokens_qwen(user_instruction+system_prompt, configs['llm_path'])
    if token_count >= 129024:
        return None, token_count
    
    messages = [{"role": "system", "content": system_prompt}, {"role": "user", "content": user_instruction}]
    text = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
    model_input = tokenizer([text], return_tensors="pt").to(configs['device'])
    attention_mask = torch.ones(model_input.input_ids.shape, dtype=torch.long, device=configs['device'])
    generated_ids = model.generate(model_input.input_ids, max_new_tokens=configs['max_new_tokens'], attention_mask=attention_mask, pad_token_id=tokenizer.eos_token_id)
    generated_ids = [output_ids[len(input_ids):] for input_ids, output_ids in zip(model_input.input_ids, generated_ids)]
    response = tokenizer.batch_decode(generated_ids, skip_special_tokens=True)[0]

    return response, token_count


if __name__ == '__main__':
    start_time = time.time() 
    
    BENCH_PATH = configs['trace_bench_dataset']
    OUTPUT_FILE = configs['output_path'] + f"/LLMresponses_{configs['llm_name']}_woFineTuning_woCoT_{configs['desc_method']}_{response_type}.json"

    test_tasks = torch.load(BENCH_PATH+'/test/preprocessed/0.pt')
    # test_tasks = dict(list(test_tasks.items())[:100])
    
    # Load LLM
    print(f"Loading {configs['llm_name']}")
    model = AutoModelForCausalLM.from_pretrained(
            configs['llm_path'],
            torch_dtype=torch.float16,
            low_cpu_mem_usage=True
        ).to(configs['device'])
    tokenizer = AutoTokenizer.from_pretrained(pretrained_model_name_or_path=configs['llm_path'], use_fast=False)
    print(f"Finish loading {configs['llm_name']}!")

    response_results = dict()
    for problem_id, task_info in tqdm(test_tasks.items(), desc='LLM Response'):
        # step1
        # user instruction
        ## instruction
        instruction_name = list()
        instruction_name.append('instruction')
        instruction_name.append(configs['desc_method'])
        instruction_name.append(response_type)
        instruction_name = '_'.join(instruction_name)
        ## input
        input_name = list()
        input_name.append('input_trace')
        input_name.append(configs['desc_method'])
        input_name = '_'.join(input_name)
        ## user instruction
        user_instruction_wo_qustion = split_from_mark(task_info[instruction_name], 'Question:')[0]
        user_instruction_qustion = split_from_mark(task_info[instruction_name], 'Question:')[1]
        input_traces = task_info[input_name]
        note_content = 'Note: The solution consists of the explicit reasoning path and the final answer. The final answer may be a number, a string, or a list, which can be empty (i.e., []). The final answer is presented within <<<>>>.'
        user_instruction = user_instruction_wo_qustion + '\n' + user_instruction_qustion + '\n' + input_traces + '\n' + note_content + '\n' + '\Answer:'
        # system prompt
        system_prompt_name = list()
        system_prompt_name.append('system_prompt')
        system_prompt_name.append(response_type)
        system_prompt_name = '_'.join(system_prompt_name)
        system_prompt = import_template(template_type='instruction', template_name=system_prompt_name)
        # response
        response_name = list()
        response_name.append('response')
        response_name.append(response_type)
        response_name = '_'.join(response_name)

        # step2
        response, token_count = ask_llm(tokenizer, model, user_instruction, system_prompt)
        
        # step3
        response_results[problem_id] = dict()
        response_results[problem_id]['task_id'] = task_info['task_id']
        response_results[problem_id]['type_id'] = task_info['type_id']
        response_results[problem_id]['gt_response'] = task_info[response_name]
        response_results[problem_id]['gt_answer'] = task_info['answer']
        response_results[problem_id]['llm_response'] = response
        response_results[problem_id]['token_count'] = token_count
    
    total_time = time.time() - start_time
    total_time_str = str(datetime.timedelta(seconds=int(total_time)))
    print("-"*20)
    print("Testing time {}".format(total_time_str))
    print("-"*20)

    with open(OUTPUT_FILE, 'w') as file:
        json.dump(response_results, file, indent=4)


    print('Done!')