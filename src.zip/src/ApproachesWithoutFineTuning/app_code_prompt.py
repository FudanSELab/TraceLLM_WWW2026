import yaml
import json
import time
import datetime
import sys
import os
import torch
import importlib
import io
import re
import contextlib
import traceback
import multiprocessing
from tqdm import tqdm
from openai import OpenAI
from langchain.prompts import PromptTemplate
from transformers import AutoModelForCausalLM, AutoTokenizer

sys.path.append(os.path.dirname(os.path.dirname(__file__)))


with open(f'./config.yaml', 'r') as f:
    configs = yaml.safe_load(f)
response_type = 'with_code'


def count_tokens_qwen(prompt, model_name):
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    tokens = tokenizer.encode(prompt, add_special_tokens=True)
    return len(tokens)


def extract_traces(text: str):
    traces = list()
    if "Input Trace 1: " in text and "Input Trace 2: " in text:
        start_1 = text.find("Input Trace 1: ") + len("Input Trace 1: ")
        start_2 = text.find("Input Trace 2: ")
        trace1 = text[start_1:start_2].strip()
        trace2 = text[start_2 + len("Input Trace 2: "):].strip()
        traces.append(trace1)
        traces.append(trace2)
    elif "Input Trace: " in text:
        trace = text.split("Input Trace: ", 1)[1].strip()
        traces.append(trace)
    return traces


def import_template(template_type, template_name):    
    if template_type == 'instruction':
        module = importlib.import_module('DatasetConstruction.Templates.InstructionTemplate')
    elif template_type == 'response':
        module = importlib.import_module('DatasetConstruction.Templates.ResponseTemplate')
    elif template_type == 'codeprompt':
        module = importlib.import_module('DatasetConstruction.Templates.CodePromptTemplate')
    return getattr(module, template_name)


def ask_llm(tokenizer, model, user_instruction, system_prompt):
    token_count = count_tokens_qwen(user_instruction+system_prompt, configs['llm_path']) 
    if token_count >= 129024:
        return None, token_count
    
    messages = [{"role": "system", "content": system_prompt}, {"role": "user", "content": user_instruction}]
    text = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
    model_input = tokenizer([text], return_tensors="pt").to(configs['device'])
    attention_mask = torch.ones(model_input.input_ids.shape, dtype=torch.long, device=configs['device'])
    generated_ids = model.generate(model_input.input_ids, max_new_tokens=configs['max_new_tokens'], attention_mask=attention_mask, pad_token_id=tokenizer.eos_token_id)
    generated_ids = [output_ids[len(input_ids):] for input_ids, output_ids in zip(model_input.input_ids, generated_ids)]
    response = tokenizer.batch_decode(generated_ids, skip_special_tokens=True)[0]

    return response, token_count


def run_code(code_response, function_call_code):
    def extract_code_block(text: str) -> str:
        code_match = re.search(r"```python(.*?)```", text, re.DOTALL)
        code = code_match.group(1).strip() if code_match else text.strip()
        code_lines = code.splitlines()
        clean_lines = [line for line in code_lines if not line.startswith("<<<")]
        return "\n".join(clean_lines)
    
    def worker(code_to_run, queue):
        output_buffer = io.StringIO()
        try:
            with contextlib.redirect_stdout(output_buffer):
                exec(code_to_run, {})
            queue.put(output_buffer.getvalue().strip())
        except Exception:
            queue.put(traceback.format_exc().strip())

    max_output_length = 1000
    timeout_seconds = 60

    code_processed = extract_code_block(code_response)
    code_to_run = code_processed + "\n" + function_call_code

    queue = multiprocessing.Queue()
    process = multiprocessing.Process(target=worker, args=(code_to_run, queue))
    process.start()
    process.join(timeout_seconds)

    if process.is_alive():
        process.terminate()
        process.join()
        return f"[TIMEOUT] Execution timed out after {timeout_seconds} seconds."

    try:
        result = queue.get_nowait()
    except Exception:
        result = "[ERROR] No output captured."
    
    return result[:max_output_length] + ("...[truncated]" if len(result) > max_output_length else "")


if __name__ == '__main__':
    start_time = time.time() 
    
    BENCH_PATH = configs['trace_bench_dataset']
    OUTPUT_FILE = configs['output_path'] + f"/LLMresponses_{configs['llm_name']}_woFineTuning_codePrompt_{configs['desc_method']}_{response_type}.json"

    test_tasks = torch.load(BENCH_PATH+'/test/preprocessed/0.pt')
    # test_tasks = dict(list(test_tasks.items())[:100])

    # Load LLM
    print(f"Loading {configs['llm_name']}")
    model = AutoModelForCausalLM.from_pretrained(
            configs['llm_path'],
            torch_dtype=torch.float16,
            low_cpu_mem_usage=True
        ).to(configs['device'])
    tokenizer = AutoTokenizer.from_pretrained(pretrained_model_name_or_path=configs['llm_path'], use_fast=False)
    print(f"Finish loading {configs['llm_name']}!")
    
    response_results = dict()
    for problem_id, task_info in tqdm(test_tasks.items(), desc='LLM Response'):
        # step1
        # user instruction
        ## code_prompt
        instruction_name = list()
        instruction_name.append('instruction')
        instruction_name.append(configs['desc_method'])
        instruction_name.append('without_step')
        instruction_name = '_'.join(instruction_name)
        instruction_content = task_info[instruction_name]
        code_task_desc = 'Your task is to write an executable Python function to solve the following question.'
        code_task_note = import_template(template_type='codeprompt', template_name='code_prompt_note')
        ## input
        input_name = list()
        input_name.append('input_trace')
        input_name.append(configs['desc_method'])
        input_name = '_'.join(input_name)
        ### input trace split
        input_traces = task_info[input_name]
        trace_list = extract_traces(input_traces)
        if len(trace_list) == 1:
            function_call_code_template = import_template(template_type='codeprompt', template_name='function_call_template_one_trace')
            function_call_code = PromptTemplate.from_template(template=function_call_code_template).format(trace1=trace_list[0])
        elif len(trace_list) == 2:
            function_call_code_template = import_template(template_type='codeprompt', template_name='function_call_template_two_traces')
            function_call_code = PromptTemplate.from_template(template=function_call_code_template).format(trace1=trace_list[0], trace2=trace_list[1])
        ## user instruction
        user_instruction = code_task_desc + '\n' + instruction_content + '\n' + task_info[input_name] + '\n' + code_task_note
        # system prompt
        system_prompt_name = list()
        system_prompt_name.append('system_prompt')
        system_prompt_name.append('with_code')
        system_prompt_name = '_'.join(system_prompt_name)
        system_prompt = import_template(template_type='instruction', template_name=system_prompt_name)
        # response
        response_name = 'response_without_step'

        # step2
        code_response, token_count = ask_llm(tokenizer, model, user_instruction, system_prompt)

        # step3
        response = run_code(code_response, function_call_code)

        # step4
        response_results[problem_id] = dict()
        response_results[problem_id]['task_id'] = task_info['task_id']
        response_results[problem_id]['type_id'] = task_info['type_id']
        response_results[problem_id]['gt_response'] = task_info[response_name]
        response_results[problem_id]['gt_answer'] = task_info['answer']
        response_results[problem_id]['llm_response'] = response
        response_results[problem_id]['token_count'] = token_count

    total_time = time.time() - start_time
    total_time_str = str(datetime.timedelta(seconds=int(total_time)))
    print("-"*20)
    print("Testing time {}".format(total_time_str))
    print("-"*20)

    with open(OUTPUT_FILE, 'w') as file:
        json.dump(response_results, file, indent=4)


    print('Done!')