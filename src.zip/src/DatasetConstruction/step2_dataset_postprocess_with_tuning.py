import json
import yaml
import os
import shutil
import torch
import importlib
from tqdm import tqdm
from utils.trace_desc_utils import *
from utils.trace_dataset import TraceDataset


trace_desc_tools = list(trace_desc_tools.keys())
response_types = ['with_step', 'without_step']


def import_template(template_type, template_name):    
    if template_type == 'instruction':
        module = importlib.import_module('Templates.InstructionTemplate')
    elif template_type == 'response':
        module = importlib.import_module('Templates.ResponseTemplate')
    elif template_type == 'codeprompt':
        module = importlib.import_module('Templates.CodePromptTemplate')
    return getattr(module, template_name)


def task_format_preprocess_Graph2Text(bench_path, task_path, type):
    tasks = torch.load(task_path)

    for trace_desc_name in trace_desc_tools:
        for response_type in response_types:
            tasks_preprocessed = list()
            for problem_id, task_info in tqdm(tasks.items(), desc=f'preprocessing {type}_tasks_Graph2Text_{trace_desc_name}_{response_type}'):
                task_info_pre = dict()
                
                # problem id
                task_info_pre['problem_id'] = problem_id
                # task id
                task_info_pre['task_id'] = task_info['task_id']
                # type id
                task_info_pre['type_id'] = task_info['type_id']
                # answer
                task_info_pre['answer'] = str(task_info['answer'])
                # instruction
                instruction_name = list()
                instruction_name.append('instruction')
                instruction_name.append(trace_desc_name)
                instruction_name.append(response_type)
                instruction_name = '_'.join(instruction_name)
                task_info_pre['instruction'] = task_info[instruction_name]
                # output
                response_name = list()
                response_name.append('response')
                response_name.append(response_type)
                response_name = '_'.join(response_name)
                task_info_pre['output'] = task_info[response_name]
                # system
                system_prompt_name = list()
                system_prompt_name.append('system_prompt')
                system_prompt_name.append(response_type)
                system_prompt_name = '_'.join(system_prompt_name)
                task_info_pre['system'] = import_template(template_type='instruction', template_name=system_prompt_name)
                # input
                input_name = list()
                input_name.append('input_trace')
                input_name.append(trace_desc_name)
                input_name = '_'.join(input_name)
                task_info_pre['input'] = task_info[input_name]

                tasks_preprocessed.append(task_info_pre)
            
            with open(bench_path+f'/{type}/preprocessed/{type}_tasks_preprocessed_Graph2Text_{trace_desc_name}_{response_type}.json', 'w') as file:
                json.dump(tasks_preprocessed, file, indent=4)
            
            update_dataset_info_Graph2Text(bench_path=bench_path, file_name=f'{type}_tasks_preprocessed_Graph2Text_{trace_desc_name}_{response_type}.json', type=f'{type}_tasks_Graph2Text_{trace_desc_name}_{response_type}')
    

def update_dataset_info_Graph2Text(bench_path, file_name, type):
    dataset_name = type

    dataset_info = dict()
    dataset_info['file_name'] = file_name
    dataset_info['columns'] = dict()
    dataset_info['columns']['prompt'] = 'instruction'
    dataset_info['columns']['query'] = 'input'
    dataset_info['columns']['response'] = 'output'
    dataset_info['columns']['system'] = 'system'
    
    if not os.path.exists(bench_path+'/dataset_info.json'):
        with open(bench_path+'/dataset_info.json', 'w') as file:
            json.dump({dataset_name: dataset_info}, file, indent=4)
    else:
        with open(bench_path+'/dataset_info.json', 'r') as file:
            dataset_dict = json.load(file)
            dataset_dict[dataset_name] = dataset_info
        with open(bench_path+'/dataset_info.json', 'w') as file:
            json.dump(dataset_dict, file, indent=4)


if __name__ == '__main__':

    # step1: load configs
    print('Step1: Start Loading Configs')
    with open(f'./config.yaml', 'r') as f:
        configs = yaml.safe_load(f)
        BENCH_PATH = configs['trace_bench_dataset']
    print('Step1: Finish')

    # step2: dataset post-processing
    print('Step2: Start Dataset Post-Processing')
    ## With Fine-tuning
    ### Graph2Text
    print('[START] Post-processing Graph2Text Dataset')        
    task_format_preprocess_Graph2Text(bench_path=BENCH_PATH, task_path=BENCH_PATH+'/train/preprocessed/0.pt', type='train')
    task_format_preprocess_Graph2Text(bench_path=BENCH_PATH, task_path=BENCH_PATH+'/test/preprocessed/0.pt', type='test')  
    shutil.copy(BENCH_PATH+'/dataset_info.json', BENCH_PATH+'/train/preprocessed/')
    shutil.copy(BENCH_PATH+'/dataset_info.json', BENCH_PATH+'/test/preprocessed/')
    # shutil.copy(BENCH_PATH+'/dataset_info.json', './src/ApproachesWithFineTuning/Graph2Text/data/dataset_info.json')
    # shutil.copy(BENCH_PATH+'/train_tasks_preprocessed_Graph2Text.json', './src/ApproachesWithFineTuning/Graph2Text/data/train_tasks_preprocessed_Graph2Text.json')
    print('[END] Post-processing Graph2Text Dataset')
    ### Graph2Token
    print('[START] Post-processing Graph2Token Dataset')
    train_dataset = TraceDataset(root=BENCH_PATH, dataset_type='train')
    test_dataset = TraceDataset(root=BENCH_PATH, dataset_type='test')
    print('[END] Post-processing Graph2Token Dataset')
    print('Step2: Finish')


    print('Done!')