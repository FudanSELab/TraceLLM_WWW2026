'''
task 4-3
'''

import torch
import json
import yaml
import random
import importlib
from tqdm import tqdm
from langchain.prompts import PromptTemplate
from utils.trace_desc_utils import * 

import uuid
namespace = uuid.NAMESPACE_DNS


client_name_kind = {'HTTP GET', 'HTTP DELETE', 'HTTP POST', 'HTTP PUT', 'GET', 'DELETE', 'POST', 'PUT'}
span_kinds = {'SPAN_KIND_CLIENT', 'SPAN_KIND_SERVER', 'SPAN_KIND_PRODUCER', 'SPAN_KIND_CONSUMER'}


class Task_4_3:
    def __init__(self):
        pass

    def generate_dataset(self, all_traces):
        with open(f'./config.yaml', 'r') as file:
            configs = yaml.safe_load(file)
        with open(f'./src/DatasetConstruction/Tasks/TaskInfo.json', 'r') as file:
            all_task_info = json.load(file)
            task_info = all_task_info[self.__class__.__name__]
        with open(f'./src/DatasetConstruction/utils/TraceFormatDesc.json', 'r') as file:
            trace_formats = json.load(file)
        
        # step1: trace pair sampling
        trace_ids = list(all_traces.keys())
        sampled_trace_pairs = list()    # [(trace_id_1, trace_id_2)]
        while len(sampled_trace_pairs) < task_info['instance_num']:
            trace_pair = set(random.sample(trace_ids, 2))
            if trace_pair not in sampled_trace_pairs:
                sampled_trace_pairs.append(trace_pair)

        problems_dict = dict()
        for trace_id_1, trace_id_2 in tqdm(sampled_trace_pairs, desc=f'{self.__class__.__name__} Instance Generation'):
            # step2: task instance generation
            task_instances, task_instances_step = self.generate_task_instance(trace_1=all_traces[trace_id_1], trace_2=all_traces[trace_id_2])

            # step3: problem generation
            ## trace format & trace desc
            trace_desc_dict = dict()
            for tool_name, tool in trace_desc_tools.items():
                trace_desc_dict[tool_name] = 'Input Trace 1: ' + tool(trace_content=all_traces[trace_id_1]) + '\n' + 'Input Trace 2: ' + tool(trace_content=all_traces[trace_id_2])       
            ## question
            traceidx_1 = all_traces[trace_id_1]['vertexs'][all_traces[trace_id_1]['edges']['0'][0]]['traceId']
            traceidx_2 = all_traces[trace_id_2]['vertexs'][all_traces[trace_id_2]['edges']['0'][0]]['traceId']
            question = task_info['question_template'].format(key_component_1=traceidx_1, key_component_2=traceidx_2)
            ## instruction
            instruction_template = self.import_template(template_type='instruction', template_name=configs['instruction_template_name'])
            instruction_template = PromptTemplate.from_template(template=instruction_template)
            instruction_content_dict = dict()
            for tool_name in trace_desc_tools.keys():
                instruction_content_dict[tool_name] = instruction_template.format(specification_name=configs['specification'],
                                                                                    trace_format=trace_formats[tool_name],
                                                                                    task_description=task_info['task_description'],
                                                                                    task_definition=task_info['task_definition'],
                                                                                    question=question,
                                                                                    trace=trace_desc_dict[tool_name]
                                                                                    )
            ## response
            ### response_with_step_template
            response_template_with_step = self.import_template(template_type='response', template_name='response_with_step_template')
            response_template_with_step = PromptTemplate.from_template(template=response_template_with_step)
            response_content_with_step = response_template_with_step.format(step=task_instances_step, answer=task_instances)
            ### response_without_step_template
            response_template_without_step = self.import_template(template_type='response', template_name='response_without_step_template')
            response_template_without_step = PromptTemplate.from_template(template=response_template_without_step)
            response_content_without_step = response_template_without_step.format(step=task_instances_step, answer=task_instances)
            ## code prompt
            codeprompt_template = self.import_template(template_type='codeprompt', template_name=configs['codeprompt_template_name'])
            codeprompt_template = PromptTemplate.from_template(template=codeprompt_template)
            codeprompt_content_dict = dict()
            for tool_name in trace_desc_tools.keys():
                codeprompt_content_dict[tool_name] = codeprompt_template.format(specification_name=configs['specification'],
                                                                                trace_format=trace_formats[tool_name],
                                                                                task_description=task_info['task_description'],
                                                                                task_definition=task_info['task_definition'],
                                                                                question=question
                                                                                )
            ## problem
            problem_id = str(uuid.uuid5(namespace, trace_id_1+trace_id_2+question))
            problem = {
                'task_id': self.__class__.__name__,
                'type_id': task_info['task_type'],
                'trace_id': [trace_id_1, trace_id_2],
                'question': question,
                'input_trace_adjacency_table_desc': trace_desc_dict['adjacency_table_desc'],
                'input_trace_edge_list_desc': trace_desc_dict['edge_list_desc'], 
                'input_trace_raw_spans_desc': trace_desc_dict['raw_spans_desc'],
                'input_trace_xml_desc': trace_desc_dict['xml_desc'],
                'instruction_adjacency_table_desc_with_step': instruction_content_dict['adjacency_table_desc']+'Let us answer this question step by step to make it correct.',
                'instruction_edge_list_desc_with_step': instruction_content_dict['edge_list_desc']+'Let us answer this question step by step to make it correct.',
                'instruction_raw_spans_desc_with_step': instruction_content_dict['raw_spans_desc']+'Let us answer this question step by step to make it correct.',
                'instruction_xml_desc_with_step': instruction_content_dict['xml_desc']+'Let us answer this question step by step to make it correct.',
                'instruction_adjacency_table_desc_without_step': instruction_content_dict['adjacency_table_desc'],
                'instruction_edge_list_desc_without_step': instruction_content_dict['edge_list_desc'],
                'instruction_raw_spans_desc_without_step': instruction_content_dict['raw_spans_desc'],
                'instruction_xml_desc_without_step': instruction_content_dict['xml_desc'],
                'step': task_instances_step,
                'response_with_step': response_content_with_step,
                'response_without_step': response_content_without_step,
                'codeprompt_adjacency_table_desc': codeprompt_content_dict['adjacency_table_desc'],
                'codeprompt_edge_list_desc': codeprompt_content_dict['edge_list_desc'],
                'codeprompt_raw_spans_desc': codeprompt_content_dict['raw_spans_desc'],
                'codeprompt_xml_desc': codeprompt_content_dict['xml_desc'],
                'answer': task_instances
            }
            problems_dict[problem_id] = problem
 
        # step4: save dataset
        problems_dict = dict(random.sample(list(problems_dict.items()), 30))
        torch.save(problems_dict, configs['trace_bench_dataset']+'/Tasks/'+self.__class__.__name__+'.pt')


    def generate_task_instance(self, trace_1, trace_2):
        '''
        input
        1. trace_1: dict, the trace content
        2. trace_2: dict, the trace content
        output
        1. answer: str, trace_id/same
        2. steps: str
        '''
        step_list = list()
        traceid_1 = trace_1['vertexs'][trace_1['edges']['0'][0]]['traceId']
        traceid_2 = trace_2['vertexs'][trace_2['edges']['0'][0]]['traceId']
        step = f"1. Count the number of spans in the Input Trace '{traceid_1}' and the Input Trace '{traceid_2}' independently."
        step_list.append(step)    
        # trace_1
        rootspan_idx_1 = trace_1['edges']['0'][0]
        traceId_1 = trace_1['vertexs'][rootspan_idx_1]['traceId']
        traceSpanCount_1 = len(trace_1['vertexs']) - 1
        # trace_2
        rootspan_idx_2 = trace_2['edges']['0'][0]
        traceId_2 = trace_2['vertexs'][rootspan_idx_2]['traceId']
        traceSpanCount_2 = len(trace_2['vertexs']) - 1
        step = f"The Input Trace '{traceid_1}' has {traceSpanCount_1} spans, and the Input Trace '{traceid_2}' has {traceSpanCount_2} spans."
        step_list.append(step)
        # compare
        if traceSpanCount_1 > traceSpanCount_2:
            answer = traceId_1
            step = f"2. The number of spans in the Input Trace '{traceid_1}' is greater than the number of spans in the Input Trace '{traceid_2}', so the answer is '{answer}'."
        elif traceSpanCount_1 < traceSpanCount_2:
            answer = traceId_2
            step = f"2. The number of spans in the Input Trace '{traceid_1}' is less than the number of spans in the Input Trace '{traceid_2}', so the answer is '{answer}'."
        else:
            answer = 'Same'
            step = f"2. The number of spans in the Input Trace '{traceid_1}' is equal to the number of spans in the Input Trace '{traceid_2}', so the answer is '{answer}'."
        step_list.append(step)
        steps = ' '.join(step_list)
        
        return answer, steps
    

    def import_template(self, template_type, template_name):    
        if template_type == 'instruction':
            module = importlib.import_module('Templates.InstructionTemplate')
        elif template_type == 'response':
            module = importlib.import_module('Templates.ResponseTemplate')
        elif template_type == 'codeprompt':
            module = importlib.import_module('Templates.CodePromptTemplate')
        return getattr(module, template_name)


if __name__ == "__main__":
    with open(f'./config.yaml', 'r') as f:
        configs = yaml.safe_load(f)
    
    with open(configs['abnormal_dataset'], 'r') as file:
        all_abnormal_traces = json.load(file)
    
    task_4_3 = Task_4_3()
    task_4_3.generate_dataset(all_traces=all_abnormal_traces)
    
    # for trace_id, trace_content in all_abnormal_traces.items():
    #     if len(trace_content['vertexs']) < 10:
    #         continue
    #     answer = generate_task_instance(trace=trace_content, instance_num=6)
    
    print('done')