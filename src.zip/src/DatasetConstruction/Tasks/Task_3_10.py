'''
task 3-10
'''

import torch
import json
import yaml
import random
import importlib
from tqdm import tqdm
from langchain.prompts import PromptTemplate
from utils.trace_desc_utils import * 

import uuid
namespace = uuid.NAMESPACE_DNS


client_name_kind = {'HTTP GET', 'HTTP DELETE', 'HTTP POST', 'HTTP PUT', 'GET', 'DELETE', 'POST', 'PUT'}
span_kinds = {'SPAN_KIND_CLIENT', 'SPAN_KIND_SERVER', 'SPAN_KIND_PRODUCER', 'SPAN_KIND_CONSUMER'}


class Task_3_10:
    def __init__(self):
        pass

    def generate_dataset(self, all_traces):
        with open(f'./config.yaml', 'r') as file:
            configs = yaml.safe_load(file)
        with open(f'./src/DatasetConstruction/Tasks/TaskInfo.json', 'r') as file:
            all_task_info = json.load(file)
            task_info = all_task_info[self.__class__.__name__]
        with open(f'./src/DatasetConstruction/utils/TraceFormatDesc.json', 'r') as file:
            trace_formats = json.load(file)
        
        # step1: trace sampling
        sampled_trace_count = int(len(all_traces) * task_info['trace_ratio'])
        sampled_traces = dict(random.sample(all_traces.items(), sampled_trace_count))

        problems_dict = dict()
        for trace_id, trace_content in tqdm(sampled_traces.items(), desc=f'{self.__class__.__name__} Instance Generation'):
            # step2: task instance generation
            task_instances, task_instances_step = self.generate_task_instance(trace=trace_content)

            # step3: problem generation
            ## trace format & trace desc
            trace_desc_dict = dict()
            for tool_name, tool in trace_desc_tools.items():
                trace_desc_dict[tool_name] = 'Input Trace: ' + tool(trace_content=trace_content) 
            ## question
            question = task_info['question_template']
            ## instruction
            instruction_template = self.import_template(template_type='instruction', template_name=configs['instruction_template_name'])  
            instruction_template = PromptTemplate.from_template(template=instruction_template)
            instruction_content_dict = dict()
            for tool_name in trace_desc_tools.keys():
                instruction_content_dict[tool_name] = instruction_template.format(specification_name=configs['specification'],
                                                                                    trace_format=trace_formats[tool_name],
                                                                                    task_description=task_info['task_description'],
                                                                                    task_definition=task_info['task_definition'],
                                                                                    question=question,
                                                                                    trace=trace_desc_dict[tool_name]
                                                                                    )
            ## response
            ### response_with_step_template
            response_template_with_step = self.import_template(template_type='response', template_name='response_with_step_template')
            response_template_with_step = PromptTemplate.from_template(template=response_template_with_step)
            response_content_with_step = response_template_with_step.format(step=task_instances_step, answer=task_instances)
            ### response_without_step_template
            response_template_without_step = self.import_template(template_type='response', template_name='response_without_step_template')
            response_template_without_step = PromptTemplate.from_template(template=response_template_without_step)
            response_content_without_step = response_template_without_step.format(step=task_instances_step, answer=task_instances)
            ## code prompt
            codeprompt_template = self.import_template(template_type='codeprompt', template_name=configs['codeprompt_template_name'])
            codeprompt_template = PromptTemplate.from_template(template=codeprompt_template)
            codeprompt_content_dict = dict()
            for tool_name in trace_desc_tools.keys():
                codeprompt_content_dict[tool_name] = codeprompt_template.format(specification_name=configs['specification'],
                                                                                trace_format=trace_formats[tool_name],
                                                                                task_description=task_info['task_description'],
                                                                                task_definition=task_info['task_definition'],
                                                                                question=question
                                                                                )
            ## problem
            problem_id = str(uuid.uuid5(namespace, trace_id+question))
            problem = {
                'task_id': self.__class__.__name__,
                'type_id': task_info['task_type'],
                'trace_id': trace_id,
                'question': question,
                'input_trace_adjacency_table_desc': trace_desc_dict['adjacency_table_desc'],
                'input_trace_edge_list_desc': trace_desc_dict['edge_list_desc'], 
                'input_trace_raw_spans_desc': trace_desc_dict['raw_spans_desc'],
                'input_trace_xml_desc': trace_desc_dict['xml_desc'],
                'instruction_adjacency_table_desc_with_step': instruction_content_dict['adjacency_table_desc']+'Let us answer this question step by step to make it correct.',
                'instruction_edge_list_desc_with_step': instruction_content_dict['edge_list_desc']+'Let us answer this question step by step to make it correct.',
                'instruction_raw_spans_desc_with_step': instruction_content_dict['raw_spans_desc']+'Let us answer this question step by step to make it correct.',
                'instruction_xml_desc_with_step': instruction_content_dict['xml_desc']+'Let us answer this question step by step to make it correct.',
                'instruction_adjacency_table_desc_without_step': instruction_content_dict['adjacency_table_desc'],
                'instruction_edge_list_desc_without_step': instruction_content_dict['edge_list_desc'],
                'instruction_raw_spans_desc_without_step': instruction_content_dict['raw_spans_desc'],
                'instruction_xml_desc_without_step': instruction_content_dict['xml_desc'],
                'step': task_instances_step,
                'response_with_step': response_content_with_step,
                'response_without_step': response_content_without_step,
                'codeprompt_adjacency_table_desc': codeprompt_content_dict['adjacency_table_desc'],
                'codeprompt_edge_list_desc': codeprompt_content_dict['edge_list_desc'],
                'codeprompt_raw_spans_desc': codeprompt_content_dict['raw_spans_desc'],
                'codeprompt_xml_desc': codeprompt_content_dict['xml_desc'],
                'answer': task_instances
            }
            problems_dict[problem_id] = problem
 
        # step4: save dataset
        problems_dict = dict(random.sample(list(problems_dict.items()), 30))
        torch.save(problems_dict, configs['trace_bench_dataset']+'/Tasks/'+self.__class__.__name__+'.pt')
    

    def has_cycle_dfs_with_path(self, graph):
        visited = dict()    
        path = []           
        cycle_path = []     

        for caller_service, callee_services in graph.items():
            if caller_service not in visited:
                visited[caller_service] = 0
            for callee_service in callee_services:
                if callee_service not in visited:
                    visited[callee_service] = 0

        def dfs(service):
            nonlocal cycle_path
            visited[service] = 1
            path.append(service)

            for callee_service in graph.get(service, []):
                if visited[callee_service] == 1:
                    cycle_start_index = path.index(callee_service)
                    cycle_path = path[cycle_start_index:] + [callee_service]
                    return True
                elif visited[callee_service] == 0:
                    if dfs(callee_service):
                        return True

            visited[service] = 2
            path.pop()
            return False

        for service in graph.keys():
            if visited[service] == 0:
                if dfs(service):
                    return True, cycle_path

        return False, []


    def has_cycle_dfs(self, graph):
        visited = dict()    
        for caller_service, callee_services in graph.items():
            if caller_service not in visited:
                visited[caller_service] = 0
            for callee_service in callee_services:
                if callee_service not in visited:
                    visited[callee_service] = 0
        def dfs(service):
            if visited[service] == 1:    
                return True
            if visited[service] == 2:    
                return False
            visited[service] = 1    
            for callee_service in graph[service]:
                if dfs(callee_service):
                    return True
            visited[service] = 2    
            return False
        
        for service in graph.keys():
            if visited[service] == 0:
                if dfs(service):
                    return True
        return False


    def generate_task_instance(self, trace):
        '''
        input
        1. trace: dict, the trace content
        output
        1. answer: bool, T/F
        2. steps: str
        '''
        step_list = list()
        rootspan_idx = trace['edges']['0'][0]
        rootspan_Id = trace['vertexs'][rootspan_idx]['spanId']
        step = f"1. Traverse all spans in the Input Trace to find the root span whose 'parentSpanId' is '-1'. In the Input Trace, the root span is span '{rootspan_Id}'."
        step_list.append(step)
        all_results = dict()
        for span_id, span_content in trace['vertexs'].items():
            if span_content == 'start':
                continue
            if span_content['kind'] == 'SPAN_KIND_CLIENT' and span_content['name'] in client_name_kind:
                if span_id in trace['edges']:
                    if span_content['service.name'] not in all_results:
                        all_results[span_content['service.name']] = list()
                    for child_span_id in trace['edges'][span_id]:
                        if trace['vertexs'][child_span_id]['kind'] == 'SPAN_KIND_SERVER':
                            if trace['vertexs'][child_span_id]['service.name'] not in all_results:
                                all_results[trace['vertexs'][child_span_id]['service.name']] = list()
                            if trace['vertexs'][child_span_id]['service.name'] not in all_results[span_content['service.name']]:
                                all_results[span_content['service.name']].append(trace['vertexs'][child_span_id]['service.name'])
        step = f"2. Starting from the root span '{rootspan_Id}', use Depth First Search (DFS) to traverse each service call path in the Input Trace and determine whether there is a service call loop, that is, this service call path calls the same service more than once."
        step_list.append(step)
        # answer = self.has_cycle_dfs(graph=all_results)
        has_cycle, cycle = self.has_cycle_dfs_with_path(graph=all_results)
        if has_cycle:
            answer = 'Yes'
            cycle_path = ' --> '.join(cycle)
            step = f"3. The Input Trace has such service call loop, for example '{cycle_path}', so the answer is '{answer}'."
        else:
            answer = 'No'
            step = f"3. The Input Trace does not have such service call loop, so the answer is '{answer}'."
        step_list.append(step)
        steps = ' '.join(step_list)

        return answer, steps


    def import_template(self, template_type, template_name):    
        if template_type == 'instruction':
            module = importlib.import_module('Templates.InstructionTemplate')
        elif template_type == 'response':
            module = importlib.import_module('Templates.ResponseTemplate')
        elif template_type == 'codeprompt':
            module = importlib.import_module('Templates.CodePromptTemplate')
        return getattr(module, template_name)


if __name__ == "__main__":
    with open(f'./config.yaml', 'r') as f:
        configs = yaml.safe_load(f)
    
    with open(configs['abnormal_dataset'], 'r') as file:
        all_abnormal_traces = json.load(file)
    
    task_3_10 = Task_3_10()
    task_3_10.generate_dataset(all_traces=all_abnormal_traces)
    
    # for trace_id, trace_content in all_abnormal_traces.items():
    #     if len(trace_content['vertexs']) < 10:
    #         continue
    #     answer = generate_task_instance(trace=trace_content, instance_num=6)
    
    print('done')