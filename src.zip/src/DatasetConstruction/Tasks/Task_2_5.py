'''
task 2-5
'''

import torch
import json
import yaml
import random
import importlib
from tqdm import tqdm
from langchain.prompts import PromptTemplate
from utils.trace_desc_utils import *

import uuid
namespace = uuid.NAMESPACE_DNS


client_name_kind = {'HTTP GET', 'HTTP DELETE', 'HTTP POST', 'HTTP PUT', 'GET', 'DELETE', 'POST', 'PUT'}
span_kinds = {'SPAN_KIND_CLIENT', 'SPAN_KIND_SERVER', 'SPAN_KIND_PRODUCER', 'SPAN_KIND_CONSUMER'}


class Task_2_5:
    def __init__(self):
        pass

    def generate_dataset(self, all_traces):
        with open(f'./config.yaml', 'r') as file:
            configs = yaml.safe_load(file)
        with open(f'./src/DatasetConstruction/Tasks/TaskInfo.json', 'r') as file:
            all_task_info = json.load(file)
            task_info = all_task_info[self.__class__.__name__]
        with open(f'./src/DatasetConstruction/utils/TraceFormatDesc.json', 'r') as file:
            trace_formats = json.load(file)
        
        # step1: trace sampling
        sampled_trace_count = int(len(all_traces) * task_info['trace_ratio'])
        sampled_traces = dict(random.sample(all_traces.items(), sampled_trace_count))

        problems_dict = dict()
        for trace_id, trace_content in tqdm(sampled_traces.items(), desc=f'{self.__class__.__name__} Instance Generation'):
            # step2: task instance generation
            task_instances, task_instances_step = self.generate_task_instance(trace=trace_content, instance_num=task_info['instance_num'])

            # step3: problem generation
            ## trace format & trace desc
            trace_desc_dict = dict()
            for tool_name, tool in trace_desc_tools.items():
                trace_desc_dict[tool_name] = 'Input Trace: ' + tool(trace_content=trace_content)  # 两条trace时需要改一下
            for key_component, gt_answer in task_instances.items():
                ## question
                key_component_list = key_component.split(',')
                question = task_info['question_template'].format(key_component_1=key_component_list[0], key_component_2=key_component_list[1])
                ## instruction
                instruction_template = self.import_template(template_type='instruction', template_name=configs['instruction_template_name'])  
                instruction_template = PromptTemplate.from_template(template=instruction_template)
                instruction_content_dict = dict()
                for tool_name in trace_desc_tools.keys():
                    instruction_content_dict[tool_name] = instruction_template.format(specification_name=configs['specification'],
                                                                                      trace_format=trace_formats[tool_name],
                                                                                      task_description=task_info['task_description'],
                                                                                      task_definition=task_info['task_definition'],
                                                                                      question=question,
                                                                                      trace=trace_desc_dict[tool_name]
                                                                                     )
                ## response
                ### response_with_step_template
                response_template_with_step = self.import_template(template_type='response', template_name='response_with_step_template')
                response_template_with_step = PromptTemplate.from_template(template=response_template_with_step)
                response_content_with_step = response_template_with_step.format(step=task_instances_step[key_component], answer=gt_answer)
                ### response_without_step_template
                response_template_without_step = self.import_template(template_type='response', template_name='response_without_step_template')
                response_template_without_step = PromptTemplate.from_template(template=response_template_without_step)
                response_content_without_step = response_template_without_step.format(step=task_instances_step[key_component], answer=gt_answer)
                ## code prompt
                codeprompt_template = self.import_template(template_type='codeprompt', template_name=configs['codeprompt_template_name'])
                codeprompt_template = PromptTemplate.from_template(template=codeprompt_template)
                codeprompt_content_dict = dict()
                for tool_name in trace_desc_tools.keys():
                    codeprompt_content_dict[tool_name] = codeprompt_template.format(specification_name=configs['specification'],
                                                                                    trace_format=trace_formats[tool_name],
                                                                                    task_description=task_info['task_description'],
                                                                                    task_definition=task_info['task_definition'],
                                                                                    question=question
                                                                                    )
                ## problem
                problem_id = str(uuid.uuid5(namespace, trace_id+question))
                problem = {
                    'task_id': self.__class__.__name__,
                    'type_id': task_info['task_type'],
                    'trace_id': trace_id,
                    'question': question,
                    'input_trace_adjacency_table_desc': trace_desc_dict['adjacency_table_desc'],
                    'input_trace_edge_list_desc': trace_desc_dict['edge_list_desc'], 
                    'input_trace_raw_spans_desc': trace_desc_dict['raw_spans_desc'],
                    'input_trace_xml_desc': trace_desc_dict['xml_desc'],
                    'instruction_adjacency_table_desc_with_step': instruction_content_dict['adjacency_table_desc']+'Let us answer this question step by step to make it correct.',
                    'instruction_edge_list_desc_with_step': instruction_content_dict['edge_list_desc']+'Let us answer this question step by step to make it correct.',
                    'instruction_raw_spans_desc_with_step': instruction_content_dict['raw_spans_desc']+'Let us answer this question step by step to make it correct.',
                    'instruction_xml_desc_with_step': instruction_content_dict['xml_desc']+'Let us answer this question step by step to make it correct.',
                    'instruction_adjacency_table_desc_without_step': instruction_content_dict['adjacency_table_desc'],
                    'instruction_edge_list_desc_without_step': instruction_content_dict['edge_list_desc'],
                    'instruction_raw_spans_desc_without_step': instruction_content_dict['raw_spans_desc'],
                    'instruction_xml_desc_without_step': instruction_content_dict['xml_desc'],
                    'step': task_instances_step[key_component],
                    'response_with_step': response_content_with_step,
                    'response_without_step': response_content_without_step,
                    'codeprompt_adjacency_table_desc': codeprompt_content_dict['adjacency_table_desc'],
                    'codeprompt_edge_list_desc': codeprompt_content_dict['edge_list_desc'],
                    'codeprompt_raw_spans_desc': codeprompt_content_dict['raw_spans_desc'],
                    'codeprompt_xml_desc': codeprompt_content_dict['xml_desc'],
                    'answer': gt_answer
                }
                problems_dict[problem_id] = problem
 
        # step4: save dataset
        problems_dict = dict(random.sample(list(problems_dict.items()), 30))
        torch.save(problems_dict, configs['trace_bench_dataset']+'/Tasks/'+self.__class__.__name__+'.pt')
    

    def generate_task_instance(self, trace, instance_num):
        '''
        input
        1. trace: dict, the trace content
        2. instance_num: int, the number of instances to generate
        output
        1. answer: dict, a dict of (key_component, span_id/same)
        2. steps: dict, a dict of (key_component, step)
        '''
        all_results = dict()
        all_steps = dict()
        for span_id_1 in range(len(trace['vertexs'])):
            for span_id_2 in range(span_id_1+1, len(trace['vertexs'])):
                if trace['vertexs'][str(span_id_1)] == 'start' or trace['vertexs'][str(span_id_2)] == 'start':
                    continue
                step_list = list()
                spanId_1 = trace['vertexs'][str(span_id_1)]['spanId']
                spanId_2 = trace['vertexs'][str(span_id_2)]['spanId']
                step = f"1. Traverse all spans in the Input Trace to find the span whose 'spanId' is '{spanId_1}' and the span whose 'spanId' is '{spanId_2}'."
                step_list.append(step)
                spanDuration_1 = int(trace['vertexs'][str(span_id_1)]['endTimeUnixNano']) - int(trace['vertexs'][str(span_id_1)]['startTimeUnixNano'])
                spanDuration_2 = int(trace['vertexs'][str(span_id_2)]['endTimeUnixNano']) - int(trace['vertexs'][str(span_id_2)]['startTimeUnixNano'])
                step = f"2. Calculate the response time of span '{spanId_1}' and span '{spanId_2}'. Specifically, the response time of span '{spanId_1}' is {spanDuration_1}, and the response time of span '{spanId_2}' is {spanDuration_2}."
                step_list.append(step)
                if spanDuration_1 > spanDuration_2:
                    all_results[','.join([trace['vertexs'][str(span_id_1)]['spanId'], trace['vertexs'][str(span_id_2)]['spanId']])] = trace['vertexs'][str(span_id_1)]['spanId']
                    step = f"3. The response time of span '{spanId_1}' is greater than the response time of span '{spanId_2}', so the answer is '{spanId_1}'."
                elif spanDuration_1 < spanDuration_2:
                    all_results[','.join([trace['vertexs'][str(span_id_1)]['spanId'], trace['vertexs'][str(span_id_2)]['spanId']])] = trace['vertexs'][str(span_id_2)]['spanId']
                    step = f"3. The response time of span '{spanId_1}' is less than the response time of span '{spanId_2}', so the answer is '{spanId_2}'."
                else:
                    all_results[','.join([trace['vertexs'][str(span_id_1)]['spanId'], trace['vertexs'][str(span_id_2)]['spanId']])] = 'Same'
                    step = f"3. The response time of span '{spanId_1}' is equal to the response time of span '{spanId_2}', so the answer is 'Same'."
                step_list.append(step)
                all_steps[','.join([trace['vertexs'][str(span_id_1)]['spanId'], trace['vertexs'][str(span_id_2)]['spanId']])] = ' '.join(step_list)
        answer = dict()
        all_results_list = list(all_results.items())
        if len(all_results_list) <= instance_num:
            answer = all_results
        else:
            answer = dict(random.sample(all_results_list, instance_num))
        steps = dict([(key_component, all_steps[key_component]) for key_component in answer.keys()])

        return answer, steps
    

    def import_template(self, template_type, template_name):    
        if template_type == 'instruction':
            module = importlib.import_module('Templates.InstructionTemplate')
        elif template_type == 'response':
            module = importlib.import_module('Templates.ResponseTemplate')
        elif template_type == 'codeprompt':
            module = importlib.import_module('Templates.CodePromptTemplate')
        return getattr(module, template_name)


if __name__ == "__main__":
    with open(f'./config.yaml', 'r') as f:
        configs = yaml.safe_load(f)
    
    with open(configs['abnormal_dataset'], 'r') as file:
        all_abnormal_traces = json.load(file)
    
    task_2_5 = Task_2_5()
    task_2_5.generate_dataset(all_traces=all_abnormal_traces)
    
    # for trace_id, trace_content in all_abnormal_traces.items():
    #     if len(trace_content['vertexs']) < 10:
    #         continue
    #     answer = generate_task_instance(trace=trace_content, instance_num=6)
    
    print('done')