'''
task 3-21
'''

import torch
import json
import yaml
import random
import importlib
from tqdm import tqdm
from langchain.prompts import PromptTemplate
from utils.trace_desc_utils import * 

import uuid
namespace = uuid.NAMESPACE_DNS


client_name_kind = {'HTTP GET', 'HTTP DELETE', 'HTTP POST', 'HTTP PUT', 'GET', 'DELETE', 'POST', 'PUT'}
span_kinds = {'SPAN_KIND_CLIENT', 'SPAN_KIND_SERVER', 'SPAN_KIND_PRODUCER', 'SPAN_KIND_CONSUMER'}


class Task_3_21:
    def __init__(self):
        pass

    def generate_dataset(self, all_traces):
        with open(f'./config.yaml', 'r') as file:
            configs = yaml.safe_load(file)
        with open(f'./src/DatasetConstruction/Tasks/TaskInfo.json', 'r') as file:
            all_task_info = json.load(file)
            task_info = all_task_info[self.__class__.__name__]
        with open(f'./src/DatasetConstruction/utils/TraceFormatDesc.json', 'r') as file:
            trace_formats = json.load(file)
        
        # step1: trace sampling
        sampled_trace_count = int(len(all_traces) * task_info['trace_ratio'])
        sampled_traces = dict(random.sample(all_traces.items(), sampled_trace_count))

        problems_dict = dict()
        for trace_id, trace_content in tqdm(sampled_traces.items(), desc=f'{self.__class__.__name__} Instance Generation'):
            # step2: task instance generation
            task_instances, task_instances_step = self.generate_task_instance(trace=trace_content)

            # step3: problem generation
            ## trace format & trace desc
            trace_desc_dict = dict()
            for tool_name, tool in trace_desc_tools.items():
                trace_desc_dict[tool_name] = 'Input Trace: ' + tool(trace_content=trace_content) 
            ## question
            question = task_info['question_template']
            ## instruction
            instruction_template = self.import_template(template_type='instruction', template_name=configs['instruction_template_name'])  
            instruction_template = PromptTemplate.from_template(template=instruction_template)
            instruction_content_dict = dict()
            for tool_name in trace_desc_tools.keys():
                instruction_content_dict[tool_name] = instruction_template.format(specification_name=configs['specification'],
                                                                                    trace_format=trace_formats[tool_name],
                                                                                    task_description=task_info['task_description'],
                                                                                    task_definition=task_info['task_definition'],
                                                                                    question=question,
                                                                                    trace=trace_desc_dict[tool_name]
                                                                                    )
            ## response
            ### response_with_step_template
            response_template_with_step = self.import_template(template_type='response', template_name='response_with_step_template')
            response_template_with_step = PromptTemplate.from_template(template=response_template_with_step)
            response_content_with_step = response_template_with_step.format(step=task_instances_step, answer=task_instances)
            ### response_without_step_template
            response_template_without_step = self.import_template(template_type='response', template_name='response_without_step_template')
            response_template_without_step = PromptTemplate.from_template(template=response_template_without_step)
            response_content_without_step = response_template_without_step.format(step=task_instances_step, answer=task_instances)
            ## code prompt
            codeprompt_template = self.import_template(template_type='codeprompt', template_name=configs['codeprompt_template_name'])
            codeprompt_template = PromptTemplate.from_template(template=codeprompt_template)
            codeprompt_content_dict = dict()
            for tool_name in trace_desc_tools.keys():
                codeprompt_content_dict[tool_name] = codeprompt_template.format(specification_name=configs['specification'],
                                                                                trace_format=trace_formats[tool_name],
                                                                                task_description=task_info['task_description'],
                                                                                task_definition=task_info['task_definition'],
                                                                                question=question
                                                                                )
            ## problem
            problem_id = str(uuid.uuid5(namespace, trace_id+question))
            problem = {
                'task_id': self.__class__.__name__,
                'type_id': task_info['task_type'],
                'trace_id': trace_id,
                'question': question,
                'input_trace_adjacency_table_desc': trace_desc_dict['adjacency_table_desc'],
                'input_trace_edge_list_desc': trace_desc_dict['edge_list_desc'], 
                'input_trace_raw_spans_desc': trace_desc_dict['raw_spans_desc'],
                'input_trace_xml_desc': trace_desc_dict['xml_desc'],
                'instruction_adjacency_table_desc_with_step': instruction_content_dict['adjacency_table_desc']+'Let us answer this question step by step to make it correct.',
                'instruction_edge_list_desc_with_step': instruction_content_dict['edge_list_desc']+'Let us answer this question step by step to make it correct.',
                'instruction_raw_spans_desc_with_step': instruction_content_dict['raw_spans_desc']+'Let us answer this question step by step to make it correct.',
                'instruction_xml_desc_with_step': instruction_content_dict['xml_desc']+'Let us answer this question step by step to make it correct.',
                'instruction_adjacency_table_desc_without_step': instruction_content_dict['adjacency_table_desc'],
                'instruction_edge_list_desc_without_step': instruction_content_dict['edge_list_desc'],
                'instruction_raw_spans_desc_without_step': instruction_content_dict['raw_spans_desc'],
                'instruction_xml_desc_without_step': instruction_content_dict['xml_desc'],
                'step': task_instances_step,
                'response_with_step': response_content_with_step,
                'response_without_step': response_content_without_step,
                'codeprompt_adjacency_table_desc': codeprompt_content_dict['adjacency_table_desc'],
                'codeprompt_edge_list_desc': codeprompt_content_dict['edge_list_desc'],
                'codeprompt_raw_spans_desc': codeprompt_content_dict['raw_spans_desc'],
                'codeprompt_xml_desc': codeprompt_content_dict['xml_desc'],
                'answer': task_instances
            }
            problems_dict[problem_id] = problem
 
        # step4: save dataset
        problems_dict = dict(random.sample(list(problems_dict.items()), 30))
        torch.save(problems_dict, configs['trace_bench_dataset']+'/Tasks/'+self.__class__.__name__+'.pt')


    def generate_task_instance(self, trace):
        '''
        input
        1. trace: dict, the trace content
        output
        1. answer: list, span id list
        2. steps: str
        '''
        answer = list()
        step_list = list()
        step = f"1. Check each span in the Input Trace in turn. For each span, if it contains the 'http.status_code' attribute, check whether the value falls within the range 400-499 or 500-599. If it does, the span is abnormal and its 'spanId' should be recorded; otherwise, the span is normal."
        step_list.append(step)
        for span_id, span_content in trace['vertexs'].items():
            if 'http.status_code' in span_content:
                if int(int(span_content['http.status_code'])/100) != 2:
                    answer.append(span_content['spanId'])
        step = f"2. The 'spanId' of the abnormal spans in the Input Trace are {str(answer)}, so the answer is {str(answer)}."
        step_list.append(step)
        steps = ' '.join(step_list)

        return answer, steps
    

    def import_template(self, template_type, template_name):    
        if template_type == 'instruction':
            module = importlib.import_module('Templates.InstructionTemplate')
        elif template_type == 'response':
            module = importlib.import_module('Templates.ResponseTemplate')
        elif template_type == 'codeprompt':
            module = importlib.import_module('Templates.CodePromptTemplate')
        return getattr(module, template_name)


if __name__ == "__main__":
    with open(f'./config.yaml', 'r') as f:
        configs = yaml.safe_load(f)
    
    with open(configs['abnormal_dataset'], 'r') as file:
        all_abnormal_traces = json.load(file)
    
    task_3_21 = Task_3_21()
    task_3_21.generate_dataset(all_traces=all_abnormal_traces)
    
    # for trace_id, trace_content in all_abnormal_traces.items():
    #     if len(trace_content['vertexs']) < 10:
    #         continue
    #     answer = generate_task_instance(trace=trace_content, instance_num=6)
    
    print('done')