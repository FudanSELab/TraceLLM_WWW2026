import torch
import json
import yaml
import shutil
import os
import os.path as osp
import numpy as np
from tqdm import tqdm
from typing import List, Tuple, Union
from copy import deepcopy
from torch_geometric.data import Dataset
from torch_geometric.data.data import Data
from torch_geometric.data.separate import separate


client_name_kind = {'HTTP GET', 'HTTP DELETE', 'HTTP POST', 'HTTP PUT', 'GET', 'DELETE', 'POST', 'PUT'}
span_kinds = {'SPAN_KIND_CLIENT', 'SPAN_KIND_SERVER', 'SPAN_KIND_PRODUCER', 'SPAN_KIND_CONSUMER'}


with open(f'./config.yaml', 'r') as f:
    configs = yaml.safe_load(f)


class TraceDataset(Dataset):
    def __init__(self, root, transform=None, pre_transform=None, pre_filter=None, dataset_type=None):
        self.type = dataset_type
        self.processed_path = osp.join(root, dataset_type, 'processed')
        if os.path.exists(self.processed_path):
            shutil.rmtree(self.processed_path)
        os.makedirs(self.processed_path)

        super().__init__(root, transform, pre_transform, pre_filter)
    

    @property
    def raw_file_names(self) -> Union[str, List[str], Tuple]:
        file_list = []
        file_list.append(osp.join(self.root, 'all_traces.pt'))
        return file_list
    

    @property
    def processed_file_names(self) -> Union[str, List[str], Tuple]:
        file_list = []
        for file in os.listdir(self.processed_dir):
            if os.path.splitext(file)[1] == '.pt':
                if file in ['pre_filter.pt', 'pre_transform.pt']:
                    continue
                file_list.append(file)
        return file_list
    

    @property
    def processed_dir(self):
        return self.processed_path
    

    def download(self):
        pass
    

    def process(self):

        print('load all traces file:', self.raw_file_names[0])
        all_traces = torch.load(self.raw_file_names[0])
        # with open(self.raw_file_names[0], 'r') as file:
        #     all_traces = json.load(file)
        
        idx = 0
        traceid_2_pt_info = dict()
        node_attrs_info = list()
        for trace_id, trace_content in tqdm(all_traces.items(), desc=f'[{self.type}] Trace Processing'):
            node_attrs = self._get_node_attrs(trace_content)
            edge_index = self._get_adjacency_info(trace_content)
            # node num check
            num_nodes_node_attrs = len(node_attrs)
            num_nodes_edge_index = edge_index.max()+1
            assert num_nodes_node_attrs == num_nodes_edge_index, f'Dismatch: num_nodes_node_attrs: {num_nodes_node_attrs}, num_nodes_edge_index: {num_nodes_edge_index}.'
            node_attrs_info += node_attrs

            data = Data(
                node_text=node_attrs,
                edge_index=edge_index,
                trace_id=trace_id,
                y=trace_content['anomaly'],
                root_url=trace_content['root_url']
            )

            traceid_2_pt_info[trace_id] = idx
            filename = osp.join(self.processed_dir, 'data_{}.pt'.format(idx))
            torch.save(data, filename)
            idx += 1

        with open(osp.join(self.processed_dir, 'data_info.json'), 'w', encoding='utf-8') as file:
            json.dump(traceid_2_pt_info, file, indent=4)
            print('write data info success')
        
        node_attrs_info = list(set(node_attrs_info))
        with open(osp.join(self.processed_dir, 'node_attrs_info.json'), 'w', encoding='utf-8') as file:
            json.dump(node_attrs_info, file, indent=4)
            print('write node attrs info success')


    def _get_span_desc(self, span_content):
        if span_content == "start":
            return span_content
        else:
            span_attr_descs = list()
            span_attr_descs.append(f"'traceId': '{span_content['traceId']}'")
            span_attr_descs.append(f"'spanId': '{span_content['spanId']}'")
            span_attr_descs.append(f"'parentSpanId': '{span_content['parentSpanId']}'")
            span_attr_descs.append(f"'name': '{span_content['name']}'")
            span_attr_descs.append(f"'kind': '{span_content['kind']}'")
            span_attr_descs.append(f"'startTimeUnixNano': {span_content['startTimeUnixNano']}")
            span_attr_descs.append(f"'endTimeUnixNano': {span_content['endTimeUnixNano']}")
            span_attr_descs.append(f"'durationTimeUnixNano': {int(span_content['endTimeUnixNano'])-int(span_content['startTimeUnixNano'])}")
            span_attr_descs.append(f"'service.name': '{span_content['service.name']}'")
            span_attr_descs.append(f"'host.name': '{span_content['host.name']}'")
            if 'db.operation' in span_content:
                span_attr_descs.append(f"'db.operation': '{span_content['db.operation']}'")
            if 'db.sql.table' in span_content:
                span_attr_descs.append(f"'db.sql.table': '{span_content['db.sql.table']}'")
            if 'db.name' in span_content:
                span_attr_descs.append(f"'db.name': '{span_content['db.name']}'")
            if 'db.system' in span_content:
                span_attr_descs.append(f"'db.system': '{span_content['db.system']}'")
            if 'http.route' in span_content:
                span_attr_descs.append(f"'http.route': '{span_content['http.route']}'")
            if 'http.status_code' in span_content:
                span_attr_descs.append(f"'http.status_code': '{span_content['http.status_code']}'")

            span_desc = ', '.join(span_attr_descs)
            span_desc = '{' + span_desc + '}'

        return span_desc


    def _get_node_attrs(self, trace_content):
        node_attrs = list()
        for id in range(len(trace_content['vertexs'])):
            span_content = trace_content['vertexs'][str(id)]
            span_desc = self._get_span_desc(span_content)
            node_attrs.append(span_desc)
        return node_attrs


    def _get_adjacency_info(self, trace_content):
        """
        adjacency list
        [from1, from2, from3 ...] [to1, to2, to3 ...]
        """
        adj_list = [[], []]
        for from_id, to_list in trace_content['edges'].items():
            for to in to_list:
                to_id = to
                adj_list[0].append(int(from_id))
                adj_list[1].append(int(to_id))
        return torch.tensor(adj_list, dtype=torch.long)


    _dispatcher = {}


    def get(self, idx: int):
        return self.processed_file_names[idx]


    def len(self) -> int:
        return len(self.processed_file_names)


if __name__ == '__main__':
    print("start...")