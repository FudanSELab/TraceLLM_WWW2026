import torch
from transformers import AutoTokenizer, AutoModelForCausalLM


config = {
    "llm_path": "/path/to/Qwen2.5-7B-Instruct/",
    "llm_name": "Qwen2.5-7B-Instruct",
    "device": "cuda" if torch.cuda.is_available() else "cpu",
    "max_new_tokens": 512
}


REWRITE_SYSTEM_PROMPT = """You are a careful rewriting assistant.
Given an English input string consisting of one or more sentences (which could be questions, instructions, logs, or path-like expressions), your task is to rewrite each sentence individually into fluent and grammatically correct English, without changing the original meaning.

Important constraints:

Do not summarize or shorten the text.

Do not merge or delete any sentence from the input.

Rewrite each sentence separately, preserving the number of sentences.

Do not change any proper nouns, numbers, or the content inside quotation marks ("..." or '...').

Maintain technical expressions, file paths, URLs, and placeholders like {id} exactly as they appear.
"""


def load_model_and_tokenizer():
    print(f"Loading model: {config['llm_name']} from {config['llm_path']}")
    tokenizer = AutoTokenizer.from_pretrained(config["llm_path"], use_fast=False)
    model = AutoModelForCausalLM.from_pretrained(
        config["llm_path"],
        torch_dtype=torch.float16,
        low_cpu_mem_usage=True
    ).to(config["device"])
    print("Model loaded successfully!\n")
    return model, tokenizer


def rewrite_text(instruction: str) -> str:
    model, tokenizer = load_model_and_tokenizer()

    messages = [
        {"role": "system", "content": REWRITE_SYSTEM_PROMPT},
        {"role": "user", "content": instruction}
    ]

    chat_input = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
    model_inputs = tokenizer([chat_input], return_tensors="pt").to(config["device"])

    with torch.no_grad():
        generated_ids = model.generate(
            model_inputs.input_ids,
            max_new_tokens=config["max_new_tokens"],
            pad_token_id=tokenizer.eos_token_id
        )

    response = tokenizer.decode(
        generated_ids[0][model_inputs.input_ids.shape[1]:],
        skip_special_tokens=True
    )

    print("=== Rewritten Instruction ===")
    print(response.strip())
    return response.strip()


if __name__ == "__main__":
    instruction = """Below is an instruction that describes a trace analysis task. Write a response that appropriately completes the request.

## Domain Knowledge
- Trace Definition:
All traces in this task follow the OpenTelemetry specification.
- Trace Description:
Each trace is represented as a list of spans. All attributes of each span follow the OpenTelemetry specification, including 'spanId', 'parentSpanId', 'name', 'kind', 'durationTimeUnixNano', 'service.name', 'host.name', etc., where 'durationTimeUnixNano' is the difference between 'endTimeUnixNano' and 'startTimeUnixNano'. Based on the 'spanId' and 'parentSpanId', each span list can be reconstructed as a tree structure of spans, where the edges represent the caller-callee relationships between a span and its parent span. The span with 'parentSpanId' of -1 is the root span.

## Instruction
Determine whether the root URLs of two given traces are the same.
The root URL of a trace is the value of the 'http.route' attribute of its root span. Given two specific traces, you need to output 'Yes' or 'No', indicating whether the root URLs of the two traces are the same.
Question: Are the root URLs of the Input Trace 'tUcfT8TN42OBigUhSOeFbA==' and the Input Trace 'ZFO2s5C9YapHniVFISbFEw==' the same?
Let us answer this question step by step to make it correct."""

    rewrite_text(instruction)
