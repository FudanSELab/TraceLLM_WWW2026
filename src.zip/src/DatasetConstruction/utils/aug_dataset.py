import random
import string
import yaml
import json
import math
from tqdm import tqdm
from copy import deepcopy

client_name_kind = {'HTTP GET', 'HTTP DELETE', 'HTTP POST', 'HTTP PUT', 'GET', 'DELETE', 'POST', 'PUT'}


def get_cycle_aug(trace_content):
    edges = deepcopy(trace_content['edges'])
    all_nodes = list(trace_content['vertexs'].keys())

    if len(all_nodes) == 2:
        return None
    
    def dfs(start, visited):
        for neighbor in edges.get(start, []):
            if neighbor not in visited:
                visited.add(neighbor)
                dfs(neighbor, visited)
    max_attempt = 100
    for _ in range(max_attempt):
        src = random.choice(all_nodes)
        dst = random.choice(all_nodes)
        if src == dst or src == '0' or dst == '0':
            continue
        visited = set()
        dfs(dst, visited)
        if src in visited:
            if dst not in edges.get(src, []):
                if src not in edges:
                    edges[src] = []
                edges[src].append(dst)

    root_spanIdx = trace_content['edges']['0'][0]
    traceId = trace_content['vertexs'][root_spanIdx]['traceId']
    new_traceId = get_new_id(traceId)
    vertexs = deepcopy(trace_content['vertexs'])
    for span_idx, span_content in vertexs.items():
        if span_content == 'start':
            continue
        vertexs[span_idx]['traceId'] = new_traceId
    
    new_trace_content = deepcopy(trace_content)
    new_trace_content['vertexs'] = vertexs
    new_trace_content['edges'] = edges

    return new_trace_content


def get_drop_nodes_aug(trace_content):
    edges = deepcopy(trace_content['edges'])
    vertexs = deepcopy(trace_content['vertexs'])
    if len(vertexs.keys()) == 2:
        return None

    root_spanIdx = trace_content['edges']['0'][0]
    traceId = trace_content['vertexs'][root_spanIdx]['traceId']
    new_traceId = get_new_id(traceId)
    for span_idx, span_content in vertexs.items():
        if span_content == 'start':
            continue
        vertexs[span_idx]['traceId'] = new_traceId

    span_keys = list(vertexs.keys())
    drop_num = math.ceil(len(span_keys) / 4)

    drop_num = max(drop_num, 1)

    # Won't drop root span and start span
    span_keys.remove('0')
    span_keys.remove(root_spanIdx)

    if len(span_keys) == 0:
        # Only a root Span
        return None
    
    if len(span_keys) < drop_num:
        drop_num = len(span_keys)

    span_ids = [int(k) for k in span_keys if k != '0']
    span_ids.sort()
    new_idx = span_ids[-1]
    selected_nodes = [str(span_ids[i]) for i in range(len(span_ids)-drop_num, len(span_ids))]

    node_parents = {}
    for parent, child_list in edges.items():
        for child in child_list:
            node_parents[child] = parent
    node_parents[root_spanIdx] = '0'

    for node_id in selected_nodes:
        vertexs.pop(node_id, None)
        parent = node_parents[node_id]
        if node_id in edges:
            for child in edges[node_id]:
                node_parents[child] = parent
            edges[parent].extend(edges[node_id])
            edges[parent].remove(node_id)
            edges.pop(node_id, None)
        else:
            edges[parent].remove(node_id)
        
        if edges[parent] == []:
            edges.pop(parent, None)
    new_trace_content = deepcopy(trace_content)
    new_trace_content['vertexs'] = vertexs
    new_trace_content['edges'] = edges

    return new_trace_content


def get_add_nodes_aug(trace_content):
    edges = deepcopy(trace_content['edges'])
    vertexs = deepcopy(trace_content['vertexs'])
    if len(vertexs.keys()) == 2:
        return None

    root_spanIdx = edges['0'][0]
    traceId = trace_content['vertexs'][root_spanIdx]['traceId']
    new_traceId = get_new_id(traceId)
    for span_idx, span_content in vertexs.items():
        if span_content == 'start':
            continue
        vertexs[span_idx]['traceId'] = new_traceId
    
    span_keys = list(vertexs.keys())
    add_num = math.ceil(len(span_keys) / 4)
    add_num = max(add_num, 1) 

    span_keys.remove('0')
    # span_keys.remove(root_spanIdx)
    span_ids = [int(k) for k in span_keys if k != '0']
    span_ids.sort()
    new_idx = span_ids[-1]
    selected_nodes = random.sample(span_keys, k=add_num)
    
    for node in selected_nodes:
        new_idx += 1
        new_node = deepcopy(vertexs[node])
        new_node['spanId'] = str(new_idx)
        new_node['parentSpanId'] = node
        vertexs[str(new_idx)] = new_node
        if node in edges:
            edges[node].append(str(new_idx))
        else:
            edges[node] = [str(new_idx)]

    new_trace_content = deepcopy(trace_content)
    new_trace_content['vertexs'] = vertexs
    new_trace_content['edges'] = edges

    return new_trace_content


def get_response_code_error_aug(trace_content):
    edges = deepcopy(trace_content['edges'])
    vertexs = deepcopy(trace_content['vertexs'])
    if len(vertexs.keys()) == 2:
        return None    

    root_spanIdx = trace_content['edges']['0'][0]
    traceId = trace_content['vertexs'][root_spanIdx]['traceId']
    new_traceId = get_new_id(traceId)
    for span_idx, span_content in vertexs.items():
        if span_content == 'start':
            continue
        vertexs[span_idx]['traceId'] = new_traceId
    
    '''
        select span to set response code error
    '''
    span_keys = list(vertexs.keys())
    inject_num = random.randint(2, len(span_keys))
    # won't drop root span and start span
    span_keys.remove('0')
    span_keys.remove(root_spanIdx)

    if len(span_keys) == 0:
        return None
    if len(span_keys) < inject_num:
        inject_num = len(span_keys)

    span_ids = [int(k) for k in span_keys if k != '0']
    span_ids.sort()
    new_idx = span_ids[-1]

    is_changed = False
    times = 0

    while not is_changed:
        selected_nodes = random.sample(span_keys, k=inject_num)
        count = 0
        for node in selected_nodes:
            if "http.status_code" in vertexs[node]:
                # 随机选择一个4xx或5xx的状态码
                count += 1
                error_code = random.choice(['400', '401', '403', '404', '500', '502', '503'])
                vertexs[node]['http.status_code'] = error_code
                is_changed = True
        times += 1
        if times > 20:
            return None

    new_trace_content = deepcopy(trace_content)
    new_trace_content['vertexs'] = vertexs
    new_trace_content['edges'] = edges

    return new_trace_content


def get_time_error_aug(trace_content):
    edges = deepcopy(trace_content['edges'])
    vertexs = deepcopy(trace_content['vertexs'])
    if len(vertexs.keys()) == 2:
        return None
    
    root_spanIdx = trace_content['edges']['0'][0]
    traceId = trace_content['vertexs'][root_spanIdx]['traceId']
    new_traceId = get_new_id(traceId)
    for span_idx, span_content in vertexs.items():
        if span_content == 'start':
            continue
        vertexs[span_idx]['traceId'] = new_traceId

    # Get Parents of each node    
    node_parents = {}
    for parent, child_list in edges.items():
        for child in child_list:
            node_parents[child] = parent
    node_parents[root_spanIdx] = '0'

    # all_nodes = list(vertexs.keys())
    # leaf_nodes = [node for node in vertexs.keys() if node not in edges]

    span_keys = list(vertexs.keys())
    span_keys.remove('0')
    # span_keys.remove(root_spanIdx)

    time_error_nodes = random.sample(span_keys, k=1)

    def dfs_modified_parent_time(node_id, end_time):
        parent_id = node_parents[node_id]
        if parent_id == '0':
            return None

        new_end_time = max(int(vertexs[parent_id]['endTimeUnixNano']), end_time + 10000)
        # formatted_time = '{:.0f}'.format(new_end_time)
        vertexs[parent]['endTimeUnixNano'] = '{:.0f}'.format(new_end_time)

        dfs_modified_parent_time(parent_id, new_end_time)

    for node in time_error_nodes:
        start_time  = int(vertexs[node]['startTimeUnixNano'])
        end_time  = int(vertexs[node]['endTimeUnixNano'])
        duration = end_time - start_time
        modified_duration = duration * random.uniform(20, 30)  # 随机放大50到150倍
        new_end_time = start_time + modified_duration
        vertexs[node]['endTimeUnixNano'] = '{:.0f}'.format(new_end_time)
        dfs_modified_parent_time(node, new_end_time)

    new_trace_content = deepcopy(trace_content)
    new_trace_content['vertexs'] = vertexs
    # new_trace_content['edges'] = edges
    return new_trace_content


def get_span_order_error_aug(trace_content):
    edges = deepcopy(trace_content['edges'])
    vertexs = deepcopy(trace_content['vertexs'])
    
    if len(vertexs.keys()) == 2:
        return None
    
    root_spanIdx = trace_content['edges']['0'][0]
    traceId = trace_content['vertexs'][root_spanIdx]['traceId']

    new_traceId = get_new_id(traceId)
    for span_idx, span_content in vertexs.items():
        if span_content == 'start':
            continue
        vertexs[span_idx]['traceId'] = new_traceId
    
    # Get parents of each node
    node_parents = {}
    for parent, child_list in edges.items():
        for child in child_list:
            node_parents[child] = parent
    
    # Get Server Client Span-pair
    server_client_span_pair = list()
    for node_id, span_content in vertexs.items():
        if span_content == 'start':
            continue
        if span_content['kind'] == 'SPAN_KIND_SERVER':
            if node_id not in edges:
                continue

            for child_id in edges.get(node_id, []):
                if vertexs[child_id]['kind'] == 'SPAN_KIND_CLIENT' and vertexs[child_id]['name'] in client_name_kind:
                    server_client_span_pair.append((node_id, child_id))

    pairs_num = len(server_client_span_pair)

    if pairs_num < 1:
        return None
    
    span_keys = list(vertexs.keys())
    span_keys.remove('0')

    swap_num = random.randint(1, max(pairs_num // 4, 1))

    swap_nodes = random.sample(server_client_span_pair, k=swap_num)

    for pair in swap_nodes:
        first_span_id, second_span_id = pair
        first_span_parent = vertexs[first_span_id]['parentSpanId']
        second_span_parent = vertexs[second_span_id]['parentSpanId']
        # Swap vertexs
        vertexs[first_span_id], vertexs[second_span_id] = vertexs[second_span_id], vertexs[first_span_id]

        # Update spanId
        vertexs[first_span_id]['spanId'], vertexs[second_span_id]['spanId'] = first_span_id, second_span_id

        vertexs[first_span_id]['parentSpanId'], vertexs[second_span_id]['parentSpanId'] = first_span_parent, second_span_parent

    new_trace_content = deepcopy(trace_content)
    new_trace_content['vertexs'] = vertexs

    return new_trace_content


def get_new_id(id_str):
    id_suffix = ''.join(random.choices(string.ascii_letters + string.digits, k=5))
    return id_str + id_suffix


aug_method = {
    'cycle': get_cycle_aug,
    # 'drop_nodes': get_drop_nodes_aug,
    'add_nodes': get_add_nodes_aug,
    'response_code_error': get_response_code_error_aug,
    'time_error': get_time_error_aug,
    'span_order_error': get_span_order_error_aug
}


def get_augmented_traces(normal_traces, abnormal_traces, aug_ratio):
    # step1
    aug_normal_trace_count = int(len(normal_traces) * aug_ratio)
    sampled_normal_traces = dict(random.sample(list(normal_traces.items()), aug_normal_trace_count))
    
    # step2
    aug_abnormal_trace_count = int(len(abnormal_traces) * aug_ratio)
    sampled_abnormal_traces = dict(random.sample(list(abnormal_traces.items()), aug_abnormal_trace_count))
    
    # step3
    sampled_traces = dict()
    sampled_traces.update(sampled_normal_traces)
    sampled_traces.update(sampled_abnormal_traces)
    
    cycle_aug_traces, other_aug_traces = dict(), dict()
    for trace_id, trace_content in tqdm(sampled_traces.items(), desc='Trace Augment'):
        random_aug_method = random.choice(list(aug_method.keys()))
        augmented_trace = aug_method[random_aug_method](trace_content)
        new_trace_id = get_new_id(trace_id)
        if not augmented_trace:
            continue
        if random_aug_method == 'cycle':
            cycle_aug_traces[new_trace_id] = augmented_trace
        else:
            other_aug_traces[new_trace_id] = augmented_trace

    return cycle_aug_traces, other_aug_traces


if __name__ == "__main__":
    with open(f'./config.yaml', 'r') as f:
        configs = yaml.safe_load(f)
    
    with open(configs['abnormal_dataset'], 'r') as file:
        all_abnormal_traces = json.load(file)
    with open(configs['normal_dataset'], 'r') as file:
        all_normal_traces = json.load(file)
    
    aug_ratio = 0.1

    cycle_aug_traces, other_aug_traces = get_augmented_traces(all_normal_traces, all_abnormal_traces, aug_ratio)

    print('done')