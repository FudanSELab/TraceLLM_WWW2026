import yaml
import json
from tqdm import tqdm
from copy import deepcopy
import xml.etree.ElementTree as ET
from xml.dom import minidom


def get_raw_spans_desc(trace_content):
    raw_spans_list = list()

    for span_content in trace_content['vertexs'].values():
        if span_content == 'start':
            continue
        span_desc = dict()
        span_desc['traceId'] = span_content['traceId']
        span_desc['spanId'] = span_content['spanId']
        span_desc['parentSpanId'] = span_content['parentSpanId']
        span_desc['name'] = span_content['name']
        span_desc['kind'] = span_content['kind']
        span_desc['startTimeUnixNano'] = span_content['startTimeUnixNano']
        span_desc['endTimeUnixNano'] = span_content['endTimeUnixNano']
        span_desc['durationTimeUnixNano'] = str(int(span_content['endTimeUnixNano'])-int(span_content['startTimeUnixNano']))
        span_desc['service.name'] = span_content['service.name']
        span_desc['host.name'] = span_content['host.name']
        if 'db.operation' in span_content:
            span_desc['db.operation'] = span_content['db.operation']
        if 'db.sql.table' in span_content:
            span_desc['db.sql.table'] = span_content['db.sql.table']
        if 'db.name' in span_content:
            span_desc['db.name'] = span_content['db.name']
        if 'db.system' in span_content:
            span_desc['db.system'] = span_content['db.system']
        if 'http.route' in span_content:
            span_desc['http.route'] = span_content['http.route']
        if 'http.status_code' in span_content:
            span_desc['http.status_code'] = span_content['http.status_code']

        raw_spans_list.append(span_desc)

    return str(raw_spans_list)


def get_adjacency_table_desc(trace_content):
    # Node Info
    raw_spans_dict = dict()
    for span_idx, span_content in trace_content['vertexs'].items():
        if span_content == 'start':
            continue
        span_desc = dict()
        span_desc['traceId'] = span_content['traceId']
        span_desc['spanId'] = span_content['spanId']
        span_desc['parentSpanId'] = span_content['parentSpanId']
        span_desc['name'] = span_content['name']
        span_desc['kind'] = span_content['kind']
        span_desc['startTimeUnixNano'] = span_content['startTimeUnixNano']
        span_desc['endTimeUnixNano'] = span_content['endTimeUnixNano']
        span_desc['durationTimeUnixNano'] = str(int(span_content['endTimeUnixNano'])-int(span_content['startTimeUnixNano']))
        span_desc['service.name'] = span_content['service.name']
        span_desc['host.name'] = span_content['host.name']
        if 'db.operation' in span_content:
            span_desc['db.operation'] = span_content['db.operation']
        if 'db.sql.table' in span_content:
            span_desc['db.sql.table'] = span_content['db.sql.table']
        if 'db.name' in span_content:
            span_desc['db.name'] = span_content['db.name']
        if 'db.system' in span_content:
            span_desc['db.system'] = span_content['db.system']
        if 'http.route' in span_content:
            span_desc['http.route'] = span_content['http.route']
        if 'http.status_code' in span_content:
            span_desc['http.status_code'] = span_content['http.status_code']
        raw_spans_dict[span_idx] = span_desc
    
    # Adjacency Table Info
    edges_dict = deepcopy(trace_content['edges'])
    edges_dict['-1'] = edges_dict.pop('0')

    return str({'Node Info': raw_spans_dict, 'Edge Info': edges_dict})


def get_edge_list_desc(trace_content):
    # Node Info
    raw_spans_dict = dict()
    for span_idx, span_content in trace_content['vertexs'].items():
        if span_content == 'start':
            continue
        span_desc = dict()
        span_desc['traceId'] = span_content['traceId']
        span_desc['spanId'] = span_content['spanId']
        span_desc['parentSpanId'] = span_content['parentSpanId']
        span_desc['name'] = span_content['name']
        span_desc['kind'] = span_content['kind']
        span_desc['startTimeUnixNano'] = span_content['startTimeUnixNano']
        span_desc['endTimeUnixNano'] = span_content['endTimeUnixNano']
        span_desc['durationTimeUnixNano'] = str(int(span_content['endTimeUnixNano'])-int(span_content['startTimeUnixNano']))
        span_desc['service.name'] = span_content['service.name']
        span_desc['host.name'] = span_content['host.name']
        if 'db.operation' in span_content:
            span_desc['db.operation'] = span_content['db.operation']
        if 'db.sql.table' in span_content:
            span_desc['db.sql.table'] = span_content['db.sql.table']
        if 'db.name' in span_content:
            span_desc['db.name'] = span_content['db.name']
        if 'db.system' in span_content:
            span_desc['db.system'] = span_content['db.system']
        if 'http.route' in span_content:
            span_desc['http.route'] = span_content['http.route']
        if 'http.status_code' in span_content:
            span_desc['http.status_code'] = span_content['http.status_code']
        raw_spans_dict[span_idx] = span_desc
    
    # Edge List Info
    edges_dict = deepcopy(trace_content['edges'])
    edges_dict['-1'] = edges_dict.pop('0')
    edges_list = list()
    for from_idx, to_idx_list in edges_dict.items():
        for to_idx in to_idx_list:
            edges_list.append((from_idx, to_idx))
    
    return str({'Node Info': raw_spans_dict, 'Edge Info': edges_list})


def get_xml_desc(trace_content):
    # Node Info
    raw_spans_dict = dict()
    for span_idx, span_content in trace_content['vertexs'].items():
        if span_content == 'start':
            continue
        span_desc = dict()
        span_desc['traceId'] = span_content['traceId']
        span_desc['spanId'] = span_content['spanId']
        span_desc['parentSpanId'] = span_content['parentSpanId']
        span_desc['name'] = span_content['name']
        span_desc['kind'] = span_content['kind']
        span_desc['startTimeUnixNano'] = span_content['startTimeUnixNano']
        span_desc['endTimeUnixNano'] = span_content['endTimeUnixNano']
        span_desc['durationTimeUnixNano'] = str(int(span_content['endTimeUnixNano'])-int(span_content['startTimeUnixNano']))
        span_desc['service.name'] = span_content['service.name']
        span_desc['host.name'] = span_content['host.name']
        if 'db.operation' in span_content:
            span_desc['db.operation'] = span_content['db.operation']
        if 'db.sql.table' in span_content:
            span_desc['db.sql.table'] = span_content['db.sql.table']
        if 'db.name' in span_content:
            span_desc['db.name'] = span_content['db.name']
        if 'db.system' in span_content:
            span_desc['db.system'] = span_content['db.system']
        if 'http.route' in span_content:
            span_desc['http.route'] = span_content['http.route']
        if 'http.status_code' in span_content:
            span_desc['http.status_code'] = span_content['http.status_code']
        raw_spans_dict[span_idx] = span_desc

    root = ET.Element('Trace')
    xml_nodes = dict()
    for node_id, span in raw_spans_dict.items():
        span_elem = ET.Element('Span', attrib={'id': node_id})
        for key, value in span.items():
            child_elem = ET.SubElement(span_elem, key)
            child_elem.text = value
        xml_nodes[node_id] = span_elem

    # tree_nodes = {'0': ET.Element('Span', attrib={'id': '0', 'name': 'start'})}  # Head node
    children_map = dict()
    for parent, children in trace_content['edges'].items():
        children_map.setdefault(parent, []).extend(children)

    visited = set()
    def attach_children(parent_id, parent_elem):
        for child_id in children_map.get(parent_id, []):
            if child_id in visited:
                continue
            visited.add(child_id)
            child_elem = xml_nodes[child_id]
            parent_elem.append(child_elem)
            attach_children(child_id, child_elem)

    # attach_children('0', tree_nodes['0'])
    # root.append(tree_nodes['0'])
    
    for child_id in children_map.get('0', []):
        child_elem = xml_nodes[child_id]
        visited.add(child_id)
        root.append(child_elem)
        attach_children(child_id, child_elem)

    rough_string = ET.tostring(root, encoding='utf-8')

    reparsed = minidom.parseString(rough_string)
    pretty_xml = reparsed.toprettyxml(indent="  ")  # 两个空格缩进

    xml_string = ET.tostring(root, encoding='unicode')

    return xml_string


def get_xml_desc_tmp(trace_content):
    return 'xxxx'


trace_desc_tools = {
    'adjacency_table_desc': get_adjacency_table_desc,
    'edge_list_desc': get_edge_list_desc,
    'raw_spans_desc': get_raw_spans_desc,
    'xml_desc': get_xml_desc_tmp
}


if __name__ == '__main__':
    with open(f'./config.yaml', 'r') as f:
        configs = yaml.safe_load(f)

    with open(configs['abnormal_dataset'], 'r') as file:
        all_abnormal_traces = json.load(file)
    
    for trace_id, trace_content in tqdm(all_abnormal_traces.items()):
        # raw_spans_desc = trace_desc_tools['raw_spans_desc'](trace_content)
        # adjacency_table_desc = trace_desc_tools['adjacency_table_desc'](trace_content)
        # edge_list_desc = trace_desc_tools['edge_list_desc'](trace_content)
        xml_desc = trace_desc_tools['xml_desc'](trace_content)
    
    print('Done!')