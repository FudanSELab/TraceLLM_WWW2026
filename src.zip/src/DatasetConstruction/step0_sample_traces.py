import json
import os
import random
import shutil

from tqdm import tqdm


sample_count_in_each_group = 10
max_span_count = 90


INPUT_DIR = './dataset/raw_dataset/all_traces_pre/'
OUTPUT_DIR = './dataset/raw_dataset/sampled_traces/'


def sample_trace_dataset(file_name):

    print(f'Loading {file_name} may take a while...')
    
    with open(INPUT_DIR+file_name, 'r') as file:
        all_traces = json.load(file)
    
    trace_summary = dict()
    max_trace_length = float('-inf')
    for trace_id, trace_content in tqdm(all_traces.items(), desc='Grouping Traces'):
        root_url = trace_content['root_url']
        span_count = len(trace_content['vertexs'])
        if span_count > max_span_count:
            continue
        max_trace_length = max(max_trace_length, span_count)
        trace_label = f'({root_url}, {str(span_count)})'
        if trace_label not in trace_summary:
            trace_summary[trace_label] = list()
        trace_summary[trace_label].append(trace_id)
    
    sampled_trace_ids = list()
    for grouped_trace_ids in tqdm(trace_summary.values(), desc='Sampling Traces'):
        if len(grouped_trace_ids) <= sample_count_in_each_group:
            sampled_trace_ids += grouped_trace_ids
        else:
            sampled_trace_ids += random.sample(grouped_trace_ids, sample_count_in_each_group)
    print('Sampled Traces:', len(sampled_trace_ids))

    sampled_dataset = dict([(trace_id, all_traces[trace_id]) for trace_id in sampled_trace_ids])
    with open(OUTPUT_DIR+file_name, 'w') as file:
        json.dump(sampled_dataset, file, indent=4)
    
    min_span_attrs = float('inf')
    max_span_attrs = float('-inf')
    for trace_id, trace_content in sampled_dataset.items():
        for span_content in trace_content['vertexs'].values():
            if span_content == 'start':
                continue
            span_attrs_count = len(span_content)
            min_span_attrs = min(min_span_attrs, span_attrs_count)
            max_span_attrs = max(max_span_attrs, span_attrs_count)
            
    print('-'*20)
    print(f'Dataset Info of {file_name}')
    print(f'Trace Count: {len(sampled_trace_ids)}')
    print(f'Max Trace Length: {max_trace_length}')
    print(f'Min Span Attrs: {min_span_attrs}')
    print(f'Max Span Attrs: {max_span_attrs}')
    print('-'*20)
    dataset_info = {
        'trace_count': len(sampled_trace_ids),
        'max_trace_length': max_trace_length,
        'min_span_attrs': min_span_attrs,
        'max_span_attrs': max_span_attrs,
    }
    with open(OUTPUT_DIR+file_name.replace('.json', '_info.json'), 'w') as file:
        json.dump(dataset_info, file, indent=4)


if __name__ == '__main__':

    if not os.path.exists(OUTPUT_DIR):
        os.makedirs(OUTPUT_DIR)

    normal_file = 'normal_traces.json'
    abnormal_file = 'abnormal_traces.json'

    print('[Start] Sample Normal Traces')
    sample_trace_dataset(normal_file)
    print('[End] Sample Normal Traces')
    print('[Start] Sample Abnormal Traces')
    sample_trace_dataset(abnormal_file)
    print('[End] Sample Abnormal Traces')

    shutil.copy(INPUT_DIR+'node_texts.json', OUTPUT_DIR)
    shutil.copy(INPUT_DIR+'operations.json', OUTPUT_DIR)