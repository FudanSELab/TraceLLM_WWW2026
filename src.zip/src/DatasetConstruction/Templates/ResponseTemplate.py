response_with_step_template = \
"""
Let us answer this question step by step.
{step}
The answer is <<<{answer}>>>.
"""

response_without_step_template = \
"""
The answer is <<<{answer}>>>.
"""