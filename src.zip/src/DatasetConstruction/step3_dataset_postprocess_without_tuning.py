import json
import yaml
import os
import shutil
import torch
import importlib
from tqdm import tqdm
from langchain.prompts import PromptTemplate
from utils.trace_desc_utils import *


CoT_example_count = 1
trace_desc_tools = list(trace_desc_tools.keys())
response_types = ['without_step', 'with_step']


def import_template(template_type, template_name):    
    if template_type == 'instruction':
        module = importlib.import_module('Templates.InstructionTemplate')
    elif template_type == 'response':
        module = importlib.import_module('Templates.ResponseTemplate')
    elif template_type == 'codeprompt':
        module = importlib.import_module('Templates.CodePromptTemplate')
    return getattr(module, template_name)


def split_from_mark(s, mark):
    index = s.find(mark)
    if index == -1:
        return s, ''  # 如果找不到 mark，就返回原字符串和空字符串
    return s[:index], s[index:]


def task_format_preprocess_PoT(bench_path, task_path, type):
    tasks = torch.load(task_path)

    for trace_desc_name in trace_desc_tools:
        response_type = 'without_step'
        tasks_preprocessed = list()
        for problem_id, task_info in tqdm(tasks.items(), desc=f'preprocessing {type}_tasks_PoT_{trace_desc_name}_{response_type}'):
            task_info_pre = dict()
            
            # problem id
            task_info_pre['problem_id'] = problem_id
            # task id
            task_info_pre['task_id'] = task_info['task_id']
            # type id
            task_info_pre['type_id'] = task_info['type_id']
            # answer
            task_info_pre['answer'] = str(task_info['answer'])
            # instruction
            codeprompt_name = list()
            codeprompt_name.append('codeprompt')
            codeprompt_name.append(trace_desc_name)
            codeprompt_name = '_'.join(codeprompt_name)
            task_info_pre['instruction'] = task_info[codeprompt_name]
            # output
            response_name = list()
            response_name.append('response')
            response_name.append(response_type)
            response_name = '_'.join(response_name)
            task_info_pre['output'] = task_info[response_name]
            # system
            system_prompt_name = list()
            system_prompt_name.append('system_prompt')
            system_prompt_name.append('with_code')
            system_prompt_name = '_'.join(system_prompt_name)
            task_info_pre['system'] = import_template(template_type='instruction', template_name=system_prompt_name)
            # input
            input_name = list()
            input_name.append('input_trace')
            input_name.append(trace_desc_name)
            input_name = '_'.join(input_name)
            task_info_pre['input'] = task_info[input_name]

            tasks_preprocessed.append(task_info_pre)
            
            with open(bench_path+f'/{type}/preprocessed/{type}_tasks_preprocessed_PoT_{trace_desc_name}_{response_type}.json', 'w') as file:
                json.dump(tasks_preprocessed, file, indent=4)
            
            update_dataset_info_Graph2Text(bench_path=bench_path, file_name=f'{type}_tasks_preprocessed_PoT_{trace_desc_name}_{response_type}.json', type=f'{type}_tasks_PoT_{trace_desc_name}_{response_type}', label=True)


def task_format_preprocess_CoT(bench_path, task_path, type):
    tasks = torch.load(task_path)

    for trace_desc_name in trace_desc_tools:
        response_type = 'with_step'
        tasks_preprocessed = list()
        for problem_id, task_info in tqdm(tasks.items(), desc=f'preprocessing {type}_tasks_CoT_{trace_desc_name}_{response_type}'):
            task_info_pre = dict()
            
            # problem id
            task_info_pre['problem_id'] = problem_id
            # task id
            task_info_pre['task_id'] = task_info['task_id']
            # type id
            task_info_pre['type_id'] = task_info['type_id']
            # answer
            task_info_pre['answer'] = str(task_info['answer'])
            # instruction
            instruction_name = list()
            instruction_name.append('instruction')
            instruction_name.append(trace_desc_name)
            instruction_name.append(response_type)
            instruction_name = '_'.join(instruction_name)
            user_instruction_wo_qustion = split_from_mark(task_info[instruction_name], 'Question:')[0]
            user_instruction_qustion = split_from_mark(task_info[instruction_name], 'Question:')[1]
            # input
            input_name = list()
            input_name.append('input_trace')
            input_name.append(trace_desc_name)
            input_name = '_'.join(input_name)
            input_traces = task_info[input_name]
            # output
            response_name = list()
            response_name.append('response')
            response_name.append(response_type)
            response_name = '_'.join(response_name)
            task_info_pre['output'] = task_info[response_name]
            # example
            ## select example
            task_name = task_info['task_id']
            same_id_tasks = torch.load(os.path.join(bench_path, 'Tasks', f'{task_name}.pt'))
            sorted_same_id_tasks = sorted(same_id_tasks.items(), key=lambda x: x[0])
            ## import example template
            example_prompt = import_template(template_type='instruction', template_name='cot_example_template')
            example_prompt = PromptTemplate.from_template(template=example_prompt)
            ## construct example prompt
            example_prompt_content = ''
            for i in range(CoT_example_count):
                question_exp = sorted_same_id_tasks[i][1]['question']
                input_traces_exp = sorted_same_id_tasks[i][1][input_name]
                response_exp = sorted_same_id_tasks[i][1][response_name]
                example_prompt_str = example_prompt.format(example_id=str(i+1),
                                                        question=question_exp,
                                                        input_traces=input_traces_exp,
                                                        response=response_exp
                                                    )
                example_prompt_content += example_prompt_str + '\n'
            note_content = 'Note: The solution consists of the explicit reasoning path and the final answer. The final answer may be a number, a string, or a list, which can be empty (i.e., []). The final answer is presented within <<<>>>.'
            task_info_pre['instruction'] = user_instruction_wo_qustion + '\n' + example_prompt_content + '\n' + user_instruction_qustion + '\n' + input_traces + '\n' + note_content + '\n' + '\Answer:'
            # system
            system_prompt_name = list()
            system_prompt_name.append('system_prompt')
            system_prompt_name.append(response_type)
            system_prompt_name = '_'.join(system_prompt_name)
            task_info_pre['system'] = import_template(template_type='instruction', template_name=system_prompt_name)

            tasks_preprocessed.append(task_info_pre)
            
            with open(bench_path+f'/{type}/preprocessed/{type}_tasks_preprocessed_CoT_{trace_desc_name}_{response_type}.json', 'w') as file:
                json.dump(tasks_preprocessed, file, indent=4)
            
            update_dataset_info_Graph2Text(bench_path=bench_path, file_name=f'{type}_tasks_preprocessed_CoT_{trace_desc_name}_{response_type}.json', type=f'{type}_tasks_CoT_{trace_desc_name}_{response_type}', label=False)


def update_dataset_info_Graph2Text(bench_path, file_name, type, label):
    dataset_name = type

    dataset_info = dict()
    dataset_info['file_name'] = file_name
    dataset_info['columns'] = dict()
    dataset_info['columns']['prompt'] = 'instruction'
    if label:
        dataset_info['columns']['query'] = 'input'
    dataset_info['columns']['response'] = 'output'
    dataset_info['columns']['system'] = 'system'
    
    if not os.path.exists(bench_path+'/dataset_info.json'):
        with open(bench_path+'/dataset_info.json', 'w') as file:
            json.dump({dataset_name: dataset_info}, file, indent=4)
    else:
        with open(bench_path+'/dataset_info.json', 'r') as file:
            dataset_dict = json.load(file)
            dataset_dict[dataset_name] = dataset_info
        with open(bench_path+'/dataset_info.json', 'w') as file:
            json.dump(dataset_dict, file, indent=4)


if __name__ == '__main__':

    # step1: load configs
    print('Step1: Start Loading Configs')
    with open(f'./config.yaml', 'r') as f:
        configs = yaml.safe_load(f)
        BENCH_PATH = configs['trace_bench_dataset']
    print('Step1: Finish')

    # step2: dataset post-processing
    print('Step2: Start Dataset Post-Processing for PoT and CoT prompt')
    ## Without Fine-tuning
    ### PoT
    # print('[START] Post-processing PoT Dataset')        
    # task_format_preprocess_PoT(bench_path=BENCH_PATH, task_path=BENCH_PATH+'/test/preprocessed/0.pt', type='test')  
    # shutil.copy(BENCH_PATH+'/dataset_info.json', BENCH_PATH+'/test/preprocessed/')
    # print('[END] Post-processing PoT Dataset')
    ### CoT
    print('[START] Post-processing CoT Dataset')
    task_format_preprocess_CoT(bench_path=BENCH_PATH, task_path=BENCH_PATH+'/test/preprocessed/0.pt', type='test')  
    shutil.copy(BENCH_PATH+'/dataset_info.json', BENCH_PATH+'/test/preprocessed/')
    print('[END] Post-processing CoT Dataset') 
    print('Step2: Finish')


    print('Done!')