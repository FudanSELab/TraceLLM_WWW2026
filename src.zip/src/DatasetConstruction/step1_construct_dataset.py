import json
import yaml
import os
import torch
import random
import importlib
from Tasks import *
from utils.aug_dataset import get_augmented_traces
from multiprocessing import Pool


def extract_tasks(jobs, trace_dataset, trace_dataset_wo_cycle):
    TASK_DIR = './src/DatasetConstruction/Tasks/'
    for file in os.listdir(TASK_DIR):
        if file[:5] == 'Task_':
            task_name = file[:-3]
            jobs.append({
                'task_name': task_name,
                'dataset': trace_dataset if task_name=='Task_3_10' else trace_dataset_wo_cycle
            })

def work(job):
    task_name = job['task_name']
    dataset = job['dataset']
    print(f'[{task_name}]: Starting...')
    module = importlib.import_module('Tasks.'+task_name)
    Task = getattr(module, task_name)
    task = Task()
    # task = globals()[task_name]()
    task.generate_dataset(all_traces=dataset)
    print(f'[{task_name}]: Finish!')
    
def merge_tasks(bench_path):
    merged_tasks = list()
    for file in os.listdir(bench_path+'/Tasks/'):
        if file[:5] == 'Task_':
            file_path = bench_path+'/Tasks/'+file
            tasks = torch.load(file_path)
            merged_tasks.append(tasks)
    final_data = dict()
    for data in merged_tasks:
        final_data.update(data)
    torch.save(final_data, bench_path+'/all_tasks.pt')

def split_dataset(bench_path, split_ratio):
    train_tasks = list()
    test_tasks = list()
    for file in os.listdir(bench_path+'/Tasks/'):
        if file[:5] == 'Task_':
            file_path = bench_path+'/Tasks/'+file
            tasks = torch.load(file_path)
            tasks_list = list(tasks.items())
            random.shuffle(tasks_list)
            task_count = len(tasks_list)
            train_tasks += tasks_list[:int(task_count*split_ratio)]
            test_tasks += tasks_list[int(task_count*split_ratio):]
    random.shuffle(train_tasks)
    random.shuffle(test_tasks)

    return dict(train_tasks), dict(test_tasks)

def get_trace_length(all_traces, test_tasks):
    trace_length = dict()
    for task_id, task_content in test_tasks.items():
        if isinstance(task_content['trace_id'], list):
            trace_ids = task_content['trace_id']
            trace_length_0 = len(all_traces[trace_ids[0]]['vertexs'])-1
            trace_length_1 = len(all_traces[trace_ids[1]]['vertexs'])-1
            trace_length[task_id] = max(trace_length_0, trace_length_1)
        else:
            trace_id = task_content['trace_id']
            trace_length[task_id] = len(all_traces[trace_id]['vertexs'])-1
    
    return trace_length


if __name__ == '__main__':

    # step1: load configs
    print('Step1: Start Loading Configs')
    with open(f'./config.yaml', 'r') as f:
        configs = yaml.safe_load(f)
    if not os.path.exists(configs['trace_bench_dataset']+'/Tasks/'):
        os.makedirs(configs['trace_bench_dataset']+'/Tasks/')
    if not os.path.exists(configs['trace_bench_dataset']+'/train/preprocessed/'):
        os.makedirs(configs['trace_bench_dataset']+'/train/preprocessed/')
    if not os.path.exists(configs['trace_bench_dataset']+'/test/preprocessed/'):
        os.makedirs(configs['trace_bench_dataset']+'/test/preprocessed/')
    print('Step1: Finish')
    
    # step2: load traces
    print('Step2: Start Loading Traces')
    with open(configs['normal_dataset'], 'r') as file:
        all_normal_traces = json.load(file)
    with open(configs['abnormal_dataset'], 'r') as file:
        all_abnormal_traces = json.load(file)
    print('********** Normal Traces Count:', len(all_normal_traces))
    print('********** Abnormal Traces Count:', len(all_abnormal_traces))
    print('Step2: Finish')
    
    # step3: dataset augmentation
    print('Step3: Start Dataset Augmentation')
    cycle_aug_traces, other_aug_traces = get_augmented_traces(all_normal_traces, all_abnormal_traces, configs['aug_ratio'])
    print('********** Augmented Traces Count:', len(cycle_aug_traces) + len(other_aug_traces))
    all_traces_without_cycle = dict()
    all_traces_without_cycle.update(all_normal_traces)
    all_traces_without_cycle.update(all_abnormal_traces)
    all_traces_without_cycle.update(other_aug_traces)
    all_traces = dict()
    all_traces.update(all_traces_without_cycle)
    all_traces.update(cycle_aug_traces)
    print('********** All Traces Count:', len(all_traces))
    torch.save(all_traces, configs['trace_bench_dataset']+'/all_traces.pt')
    # with open(configs['trace_bench_dataset']+'/all_traces.json', 'w') as file:
    #     json.dump(all_traces, file, indent=4)
    print('Step3: Finish')

    # step4: task generation
    print('Step4: Start Task Generation')
    jobs = list()
    extract_tasks(jobs, all_traces, all_traces_without_cycle)
    print('Tasks Count:', len(jobs))   
    with Pool(configs['processes_num']) as p:
        p.map(work, jobs)
    # for job in jobs:
    #     work(job)
    merge_tasks(configs['trace_bench_dataset'])
    print('Step4: Finish')

    # step5: dataset generation
    print('Step5: Start Dataset Generation')
    train_tasks, test_tasks = split_dataset(configs['trace_bench_dataset'], configs['split_ratio'])
    torch.save(train_tasks, configs['trace_bench_dataset']+'/train/preprocessed/0.pt')
    torch.save(test_tasks, configs['trace_bench_dataset']+'/test/preprocessed/0.pt')
    print('Train Tasks Count:', len(train_tasks))
    print('Test Tasks Count:', len(test_tasks))
    print('Step5: Finish')

    # step6: trace length calculation
    print('Step6: Start Trace Length Calculation')
    trace_length = get_trace_length(all_traces, test_tasks)
    with open(configs['trace_bench_dataset']+'/test/preprocessed/trace_length.json', 'w') as file:
        json.dump(trace_length, file, indent=4)
    print('Step6: Finish')

    print('Done!')