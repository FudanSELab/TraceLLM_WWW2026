# python src/ApproachesWithFineTuning/Graph2Text/inference.py


#!/bin/bash

FT_TYPE=lora
TRACE_DESC=raw_spans_desc
RESPONSE_TYPE=with_step
MODEL_NAME=Meta-Llama-3-8B-Instruct
CODE_PATH=src/ApproachesWithFineTuning/Graph2Text
MODEL_PATH=/path/to/${MODEL_NAME}
TraceBench_PATH=dataset/TraceBench
OUTPUT_PATH=output/${MODEL_NAME}/${FT_TYPE}/sft/${TRACE_DESC}_${RESPONSE_TYPE}/

CUDA_VISIBLE_DEVICES=0 torchrun --master_port=29504 ${CODE_PATH}/src/train.py \
    --stage sft \
    --do_predict \
    --predict_with_generate \
    --model_name_or_path ${MODEL_PATH} \
    --adapter_name_or_path ${OUTPUT_PATH} \
    --dataset_dir ${TraceBench_PATH}/test/preprocessed \
    --eval_dataset test_tasks_Graph2Text_${TRACE_DESC}_${RESPONSE_TYPE} \
    --template llama3  \
    --finetuning_type ${FT_TYPE} \
    --per_device_eval_batch_size 12 \
    --output_dir ${OUTPUT_PATH} \
    --overwrite_output_dir \
    --logging_steps 100 \
    --plot_loss \
    --bf16 \
    --preprocessing_num_workers 4 \
    --trust_remote_code True \
    --overwrite_cache \