#!/bin/bash

FT_TYPE=lora
TRACE_DESC=raw_spans_desc
RESPONSE_TYPE=with_step
MODEL_NAME=DeepSeek-R1-Distill-Llama-8B
CODE_PATH=src/ApproachesWithFineTuning/Graph2Text
MODEL_PATH=/path/to/${MODEL_NAME}
TraceBench_PATH=dataset/TraceBench
OUTPUT_PATH=output/${MODEL_NAME}/${FT_TYPE}/sft/${TRACE_DESC}_${RESPONSE_TYPE}/

DEEPSPEED_TIMEOUT=120 WANDB_MODE=offline deepspeed --include localhost:0 --master_port=19903 ${CODE_PATH}/src/train.py \
    --deepspeed ${CODE_PATH}/ds_config/ds_config_3_${FT_TYPE}.json \
    --stage sft \
    --model_name_or_path ${MODEL_PATH} \
    --dataset_dir ${TraceBench_PATH}/train/preprocessed \
    --dataset train_tasks_Graph2Text_${TRACE_DESC}_${RESPONSE_TYPE} \
    --do_train \
    --template llama3  \
    --finetuning_type ${FT_TYPE} \
    --lora_rank 8 \
    --lora_target all \
    --output_dir ${OUTPUT_PATH} \
    --overwrite_output_dir \
    --per_device_train_batch_size 5 \
    --gradient_accumulation_steps 1 \
    --lr_scheduler_type cosine \
    --logging_steps 100 \
    --learning_rate 1e-5 \
    --weight_decay 0. \
    --warmup_ratio 0.02 \
    --num_train_epochs 3 \
    --plot_loss \
    --bf16 \
    --save_strategy "epoch" \
    --save_total_limit 6 \
    --save_only_model \
    --save_safetensors False \
    --preprocessing_num_workers 4 \
    --trust_remote_code True \
    --overwrite_cache \